vsim -do "runsim.do"
