// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vvga_ball__Syms.h"


//======================

void Vvga_ball::trace(VerilatedVcdC* tfp, int, int) {
    tfp->spTrace()->addCallback(&Vvga_ball::traceInit, &Vvga_ball::traceFull, &Vvga_ball::traceChg, this);
}
void Vvga_ball::traceInit(VerilatedVcd* vcdp, void* userthis, uint32_t code) {
    // Callback from vcd->open()
    Vvga_ball* t=(Vvga_ball*)userthis;
    Vvga_ball__Syms* __restrict vlSymsp = t->__VlSymsp;  // Setup global symbol table
    if (!Verilated::calcUnusedSigs()) {
	VL_FATAL_MT(__FILE__,__LINE__,__FILE__,"Turning on wave traces requires Verilated::traceEverOn(true) call before time 0.");
    }
    vcdp->scopeEscape(' ');
    t->traceInitThis(vlSymsp, vcdp, code);
    vcdp->scopeEscape('.');
}
void Vvga_ball::traceFull(VerilatedVcd* vcdp, void* userthis, uint32_t code) {
    // Callback from vcd->dump()
    Vvga_ball* t=(Vvga_ball*)userthis;
    Vvga_ball__Syms* __restrict vlSymsp = t->__VlSymsp;  // Setup global symbol table
    t->traceFullThis(vlSymsp, vcdp, code);
}

//======================


void Vvga_ball::traceInitThis(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    vcdp->module(vlSymsp->name());  // Setup signal names
    // Body
    {
	vlTOPp->traceInitThis__1(vlSymsp, vcdp, code);
    }
}

void Vvga_ball::traceFullThis(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vlTOPp->traceFullThis__1(vlSymsp, vcdp, code);
    }
    // Final
    vlTOPp->__Vm_traceActivity = 0U;
}

void Vvga_ball::traceInitThis__1(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->declBit  (c+299,"clk",-1);
	vcdp->declBit  (c+300,"reset",-1);
	vcdp->declBus  (c+301,"writedata",-1,31,0);
	vcdp->declBit  (c+302,"write",-1);
	vcdp->declBit  (c+303,"chipselect",-1);
	vcdp->declBus  (c+304,"address",-1,3,0);
	vcdp->declBus  (c+305,"VGA_R",-1,7,0);
	vcdp->declBus  (c+306,"VGA_G",-1,7,0);
	vcdp->declBus  (c+307,"VGA_B",-1,7,0);
	vcdp->declBit  (c+308,"VGA_CLK",-1);
	vcdp->declBit  (c+309,"VGA_HS",-1);
	vcdp->declBit  (c+310,"VGA_VS",-1);
	vcdp->declBit  (c+311,"VGA_BLANK_n",-1);
	vcdp->declBit  (c+312,"VGA_SYNC_n",-1);
	vcdp->declBit  (c+299,"vga_ball clk",-1);
	vcdp->declBit  (c+300,"vga_ball reset",-1);
	vcdp->declBus  (c+301,"vga_ball writedata",-1,31,0);
	vcdp->declBit  (c+302,"vga_ball write",-1);
	vcdp->declBit  (c+303,"vga_ball chipselect",-1);
	vcdp->declBus  (c+304,"vga_ball address",-1,3,0);
	vcdp->declBus  (c+305,"vga_ball VGA_R",-1,7,0);
	vcdp->declBus  (c+306,"vga_ball VGA_G",-1,7,0);
	vcdp->declBus  (c+307,"vga_ball VGA_B",-1,7,0);
	vcdp->declBit  (c+308,"vga_ball VGA_CLK",-1);
	vcdp->declBit  (c+309,"vga_ball VGA_HS",-1);
	vcdp->declBit  (c+310,"vga_ball VGA_VS",-1);
	vcdp->declBit  (c+311,"vga_ball VGA_BLANK_n",-1);
	vcdp->declBit  (c+312,"vga_ball VGA_SYNC_n",-1);
	vcdp->declBus  (c+295,"vga_ball hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball vcount",-1,9,0);
	{int i; for (i=0; i<6; i++) {
		vcdp->declBus  (c+21+i*1,"vga_ball out_pixel",(i+0),3,0);}}
	vcdp->declBus  (c+27,"vga_ball final_out_pixel",-1,3,0);
	vcdp->declBus  (c+47,"vga_ball background_r",-1,7,0);
	vcdp->declBus  (c+48,"vga_ball background_g",-1,7,0);
	vcdp->declBus  (c+49,"vga_ball background_b",-1,7,0);
	vcdp->declBus  (c+28,"vga_ball rgb_val",-1,23,0);
	vcdp->declBus  (c+50,"vga_ball ra_n",-1,11,0);
	vcdp->declBus  (c+51,"vga_ball wa_n",-1,11,0);
	vcdp->declBit  (c+52,"vga_ball we_n",-1);
	vcdp->declBus  (c+53,"vga_ball din_n",-1,7,0);
	vcdp->declBus  (c+54,"vga_ball dout_n",-1,7,0);
	vcdp->declBus  (c+55,"vga_ball ra_pg",-1,10,0);
	vcdp->declBus  (c+56,"vga_ball wa_pg",-1,10,0);
	vcdp->declBit  (c+57,"vga_ball we_pg",-1);
	vcdp->declBus  (c+58,"vga_ball din_pg",-1,7,0);
	vcdp->declBus  (c+59,"vga_ball dout_pg",-1,7,0);
	vcdp->declBus  (c+39,"vga_ball ra_a",-1,4,0);
	vcdp->declBus  (c+60,"vga_ball wa_a",-1,4,0);
	vcdp->declBit  (c+61,"vga_ball we_a",-1);
	vcdp->declBus  (c+62,"vga_ball din_a",-1,7,0);
	vcdp->declBus  (c+63,"vga_ball dout_a",-1,7,0);
	vcdp->declBus  (c+40,"vga_ball ra_g",-1,10,0);
	vcdp->declBus  (c+64,"vga_ball wa_g",-1,10,0);
	vcdp->declBit  (c+65,"vga_ball we_g",-1);
	vcdp->declBus  (c+66,"vga_ball din_g",-1,7,0);
	vcdp->declBus  (c+67,"vga_ball dout_g",-1,7,0);
	{int i; for (i=0; i<5; i++) {
		vcdp->declBus  (c+1+i*1,"vga_ball sprite_base_addr",(i+0),4,0);}}
	{int i; for (i=0; i<5; i++) {
		vcdp->declBus  (c+6+i*1,"vga_ball h_start",(i+0),10,0);}}
	{int i; for (i=0; i<5; i++) {
		vcdp->declBus  (c+29+i*1,"vga_ball sprite_ra_a",(i+0),4,0);}}
	{int i; for (i=0; i<5; i++) {
		vcdp->declBus  (c+34+i*1,"vga_ball sprite_ra_g",(i+0),10,0);}}
	vcdp->declBit  (c+299,"vga_ball counters clk50",-1);
	vcdp->declBit  (c+300,"vga_ball counters reset",-1);
	vcdp->declBus  (c+295,"vga_ball counters hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball counters vcount",-1,9,0);
	vcdp->declBit  (c+308,"vga_ball counters VGA_CLK",-1);
	vcdp->declBit  (c+309,"vga_ball counters VGA_HS",-1);
	vcdp->declBit  (c+310,"vga_ball counters VGA_VS",-1);
	vcdp->declBit  (c+311,"vga_ball counters VGA_BLANK_n",-1);
	vcdp->declBit  (c+312,"vga_ball counters VGA_SYNC_n",-1);
	vcdp->declBus  (c+313,"vga_ball counters HACTIVE",-1,10,0);
	vcdp->declBus  (c+314,"vga_ball counters HFRONT_PORCH",-1,10,0);
	vcdp->declBus  (c+315,"vga_ball counters HSYNC",-1,10,0);
	vcdp->declBus  (c+316,"vga_ball counters HBACK_PORCH",-1,10,0);
	vcdp->declBus  (c+317,"vga_ball counters HTOTAL",-1,10,0);
	vcdp->declBus  (c+318,"vga_ball counters VACTIVE",-1,9,0);
	vcdp->declBus  (c+319,"vga_ball counters VFRONT_PORCH",-1,9,0);
	vcdp->declBus  (c+320,"vga_ball counters VSYNC",-1,9,0);
	vcdp->declBus  (c+321,"vga_ball counters VBACK_PORCH",-1,9,0);
	vcdp->declBus  (c+322,"vga_ball counters VTOTAL",-1,9,0);
	vcdp->declBit  (c+297,"vga_ball counters endOfLine",-1);
	vcdp->declBit  (c+298,"vga_ball counters endOfField",-1);
	vcdp->declBit  (c+299,"vga_ball pn1 clk",-1);
	vcdp->declBus  (c+50,"vga_ball pn1 ra",-1,11,0);
	vcdp->declBus  (c+51,"vga_ball pn1 wa",-1,11,0);
	vcdp->declBit  (c+52,"vga_ball pn1 we",-1);
	vcdp->declBus  (c+53,"vga_ball pn1 din",-1,7,0);
	vcdp->declBus  (c+54,"vga_ball pn1 dout",-1,7,0);
	// Tracing: vga_ball pn1 mem // Ignored: Wide memory > --trace-max-array ents at vga_ball.sv:425
	vcdp->declBit  (c+299,"vga_ball pg1 clk",-1);
	vcdp->declBus  (c+55,"vga_ball pg1 ra",-1,10,0);
	vcdp->declBus  (c+56,"vga_ball pg1 wa",-1,10,0);
	vcdp->declBit  (c+57,"vga_ball pg1 we",-1);
	vcdp->declBus  (c+58,"vga_ball pg1 din",-1,7,0);
	vcdp->declBus  (c+59,"vga_ball pg1 dout",-1,7,0);
	// Tracing: vga_ball pg1 mem // Ignored: Wide memory > --trace-max-array ents at vga_ball.sv:440
	vcdp->declBit  (c+299,"vga_ball sat1 clk",-1);
	vcdp->declBus  (c+39,"vga_ball sat1 ra",-1,4,0);
	vcdp->declBus  (c+60,"vga_ball sat1 wa",-1,4,0);
	vcdp->declBit  (c+61,"vga_ball sat1 we",-1);
	vcdp->declBus  (c+62,"vga_ball sat1 din",-1,7,0);
	vcdp->declBus  (c+63,"vga_ball sat1 dout",-1,7,0);
	{int i; for (i=0; i<32; i++) {
		vcdp->declBus  (c+68+i*1,"vga_ball sat1 mem",(i+0),7,0);}}
	vcdp->declBit  (c+299,"vga_ball sgt1 clk",-1);
	vcdp->declBus  (c+40,"vga_ball sgt1 ra",-1,10,0);
	vcdp->declBus  (c+64,"vga_ball sgt1 wa",-1,10,0);
	vcdp->declBit  (c+65,"vga_ball sgt1 we",-1);
	vcdp->declBus  (c+66,"vga_ball sgt1 din",-1,7,0);
	vcdp->declBus  (c+67,"vga_ball sgt1 dout",-1,7,0);
	// Tracing: vga_ball sgt1 mem // Ignored: Wide memory > --trace-max-array ents at vga_ball.sv:410
	vcdp->declBus  (c+27,"vga_ball cl1 color_code",-1,3,0);
	vcdp->declBus  (c+28,"vga_ball cl1 rgb_val",-1,23,0);
	vcdp->declBit  (c+299,"vga_ball pp0 clk",-1);
	vcdp->declBit  (c+300,"vga_ball pp0 reset",-1);
	vcdp->declBus  (c+295,"vga_ball pp0 hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball pp0 vcount",-1,9,0);
	vcdp->declBit  (c+311,"vga_ball pp0 VGA_BLANK_n",-1);
	vcdp->declBus  (c+54,"vga_ball pp0 dout_n",-1,7,0);
	vcdp->declBus  (c+59,"vga_ball pp0 dout_g",-1,7,0);
	vcdp->declBus  (c+50,"vga_ball pp0 ra_n",-1,11,0);
	vcdp->declBus  (c+55,"vga_ball pp0 ra_g",-1,10,0);
	vcdp->declBus  (c+100,"vga_ball pp0 out_pixel",-1,3,0);
	vcdp->declArray(c+101,"vga_ball pp0 shift_reg",-1,2047,0);
	vcdp->declBus  (c+165,"vga_ball pp0 shift_pos",-1,11,0);
	vcdp->declBus  (c+166,"vga_ball pp0 pattern_row_offset",-1,10,0);
	vcdp->declArray(c+167,"vga_ball pp0 display_pixel",-1,2047,0);
	vcdp->declBus  (c+231,"vga_ball pp0 shift_reg_shift",-1,11,0);
	vcdp->declBus  (c+232,"vga_ball pp0 tile_total_counter",-1,7,0);
	vcdp->declBus  (c+233,"vga_ball pp0 tile_pixel_counter",-1,7,0);
	vcdp->declBus  (c+323,"vga_ball pp0 v_start",-1,11,0);
	vcdp->declBus  (c+324,"vga_ball pp0 tiles_per_row",-1,7,0);
	vcdp->declBus  (c+325,"vga_ball pp0 name_table_addr_mask",-1,11,0);
	vcdp->declBus  (c+234,"vga_ball pp0 state",-1,31,0);
	vcdp->declBus  (c+41,"vga_ball pp0 state_next",-1,31,0);
	vcdp->declBit  (c+299,"vga_ball sp0 clk",-1);
	vcdp->declBit  (c+300,"vga_ball sp0 reset",-1);
	vcdp->declBus  (c+11,"vga_ball sp0 h_start",-1,10,0);
	vcdp->declBus  (c+295,"vga_ball sp0 hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball sp0 vcount",-1,9,0);
	vcdp->declBit  (c+311,"vga_ball sp0 VGA_BLANK_n",-1);
	vcdp->declBus  (c+12,"vga_ball sp0 base_addr",-1,4,0);
	vcdp->declBus  (c+63,"vga_ball sp0 dout_a",-1,7,0);
	vcdp->declBus  (c+67,"vga_ball sp0 dout_g",-1,7,0);
	vcdp->declBus  (c+235,"vga_ball sp0 ra_a",-1,4,0);
	vcdp->declBus  (c+236,"vga_ball sp0 ra_g",-1,10,0);
	vcdp->declBus  (c+237,"vga_ball sp0 out_pixel",-1,3,0);
	vcdp->declBus  (c+238,"vga_ball sp0 down_counter",-1,8,0);
	vcdp->declQuad (c+239,"vga_ball sp0 shift_reg",-1,63,0);
	vcdp->declBus  (c+241,"vga_ball sp0 shift_pos",-1,7,0);
	vcdp->declBus  (c+242,"vga_ball sp0 sprite_offset",-1,10,0);
	vcdp->declQuad (c+243,"vga_ball sp0 display_pixel",-1,63,0);
	vcdp->declBus  (c+245,"vga_ball sp0 shift_reg_shift",-1,7,0);
	vcdp->declBus  (c+246,"vga_ball sp0 state",-1,31,0);
	vcdp->declBus  (c+42,"vga_ball sp0 state_next",-1,31,0);
	vcdp->declBit  (c+299,"vga_ball sp1 clk",-1);
	vcdp->declBit  (c+300,"vga_ball sp1 reset",-1);
	vcdp->declBus  (c+13,"vga_ball sp1 h_start",-1,10,0);
	vcdp->declBus  (c+295,"vga_ball sp1 hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball sp1 vcount",-1,9,0);
	vcdp->declBit  (c+311,"vga_ball sp1 VGA_BLANK_n",-1);
	vcdp->declBus  (c+14,"vga_ball sp1 base_addr",-1,4,0);
	vcdp->declBus  (c+63,"vga_ball sp1 dout_a",-1,7,0);
	vcdp->declBus  (c+67,"vga_ball sp1 dout_g",-1,7,0);
	vcdp->declBus  (c+247,"vga_ball sp1 ra_a",-1,4,0);
	vcdp->declBus  (c+248,"vga_ball sp1 ra_g",-1,10,0);
	vcdp->declBus  (c+249,"vga_ball sp1 out_pixel",-1,3,0);
	vcdp->declBus  (c+250,"vga_ball sp1 down_counter",-1,8,0);
	vcdp->declQuad (c+251,"vga_ball sp1 shift_reg",-1,63,0);
	vcdp->declBus  (c+253,"vga_ball sp1 shift_pos",-1,7,0);
	vcdp->declBus  (c+254,"vga_ball sp1 sprite_offset",-1,10,0);
	vcdp->declQuad (c+255,"vga_ball sp1 display_pixel",-1,63,0);
	vcdp->declBus  (c+257,"vga_ball sp1 shift_reg_shift",-1,7,0);
	vcdp->declBus  (c+258,"vga_ball sp1 state",-1,31,0);
	vcdp->declBus  (c+43,"vga_ball sp1 state_next",-1,31,0);
	vcdp->declBit  (c+299,"vga_ball sp2 clk",-1);
	vcdp->declBit  (c+300,"vga_ball sp2 reset",-1);
	vcdp->declBus  (c+15,"vga_ball sp2 h_start",-1,10,0);
	vcdp->declBus  (c+295,"vga_ball sp2 hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball sp2 vcount",-1,9,0);
	vcdp->declBit  (c+311,"vga_ball sp2 VGA_BLANK_n",-1);
	vcdp->declBus  (c+16,"vga_ball sp2 base_addr",-1,4,0);
	vcdp->declBus  (c+63,"vga_ball sp2 dout_a",-1,7,0);
	vcdp->declBus  (c+67,"vga_ball sp2 dout_g",-1,7,0);
	vcdp->declBus  (c+259,"vga_ball sp2 ra_a",-1,4,0);
	vcdp->declBus  (c+260,"vga_ball sp2 ra_g",-1,10,0);
	vcdp->declBus  (c+261,"vga_ball sp2 out_pixel",-1,3,0);
	vcdp->declBus  (c+262,"vga_ball sp2 down_counter",-1,8,0);
	vcdp->declQuad (c+263,"vga_ball sp2 shift_reg",-1,63,0);
	vcdp->declBus  (c+265,"vga_ball sp2 shift_pos",-1,7,0);
	vcdp->declBus  (c+266,"vga_ball sp2 sprite_offset",-1,10,0);
	vcdp->declQuad (c+267,"vga_ball sp2 display_pixel",-1,63,0);
	vcdp->declBus  (c+269,"vga_ball sp2 shift_reg_shift",-1,7,0);
	vcdp->declBus  (c+270,"vga_ball sp2 state",-1,31,0);
	vcdp->declBus  (c+44,"vga_ball sp2 state_next",-1,31,0);
	vcdp->declBit  (c+299,"vga_ball sp3 clk",-1);
	vcdp->declBit  (c+300,"vga_ball sp3 reset",-1);
	vcdp->declBus  (c+17,"vga_ball sp3 h_start",-1,10,0);
	vcdp->declBus  (c+295,"vga_ball sp3 hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball sp3 vcount",-1,9,0);
	vcdp->declBit  (c+311,"vga_ball sp3 VGA_BLANK_n",-1);
	vcdp->declBus  (c+18,"vga_ball sp3 base_addr",-1,4,0);
	vcdp->declBus  (c+63,"vga_ball sp3 dout_a",-1,7,0);
	vcdp->declBus  (c+67,"vga_ball sp3 dout_g",-1,7,0);
	vcdp->declBus  (c+271,"vga_ball sp3 ra_a",-1,4,0);
	vcdp->declBus  (c+272,"vga_ball sp3 ra_g",-1,10,0);
	vcdp->declBus  (c+273,"vga_ball sp3 out_pixel",-1,3,0);
	vcdp->declBus  (c+274,"vga_ball sp3 down_counter",-1,8,0);
	vcdp->declQuad (c+275,"vga_ball sp3 shift_reg",-1,63,0);
	vcdp->declBus  (c+277,"vga_ball sp3 shift_pos",-1,7,0);
	vcdp->declBus  (c+278,"vga_ball sp3 sprite_offset",-1,10,0);
	vcdp->declQuad (c+279,"vga_ball sp3 display_pixel",-1,63,0);
	vcdp->declBus  (c+281,"vga_ball sp3 shift_reg_shift",-1,7,0);
	vcdp->declBus  (c+282,"vga_ball sp3 state",-1,31,0);
	vcdp->declBus  (c+45,"vga_ball sp3 state_next",-1,31,0);
	vcdp->declBit  (c+299,"vga_ball sp4 clk",-1);
	vcdp->declBit  (c+300,"vga_ball sp4 reset",-1);
	vcdp->declBus  (c+19,"vga_ball sp4 h_start",-1,10,0);
	vcdp->declBus  (c+295,"vga_ball sp4 hcount",-1,10,0);
	vcdp->declBus  (c+296,"vga_ball sp4 vcount",-1,9,0);
	vcdp->declBit  (c+311,"vga_ball sp4 VGA_BLANK_n",-1);
	vcdp->declBus  (c+20,"vga_ball sp4 base_addr",-1,4,0);
	vcdp->declBus  (c+63,"vga_ball sp4 dout_a",-1,7,0);
	vcdp->declBus  (c+67,"vga_ball sp4 dout_g",-1,7,0);
	vcdp->declBus  (c+283,"vga_ball sp4 ra_a",-1,4,0);
	vcdp->declBus  (c+284,"vga_ball sp4 ra_g",-1,10,0);
	vcdp->declBus  (c+285,"vga_ball sp4 out_pixel",-1,3,0);
	vcdp->declBus  (c+286,"vga_ball sp4 down_counter",-1,8,0);
	vcdp->declQuad (c+287,"vga_ball sp4 shift_reg",-1,63,0);
	vcdp->declBus  (c+289,"vga_ball sp4 shift_pos",-1,7,0);
	vcdp->declBus  (c+290,"vga_ball sp4 sprite_offset",-1,10,0);
	vcdp->declQuad (c+291,"vga_ball sp4 display_pixel",-1,63,0);
	vcdp->declBus  (c+293,"vga_ball sp4 shift_reg_shift",-1,7,0);
	vcdp->declBus  (c+294,"vga_ball sp4 state",-1,31,0);
	vcdp->declBus  (c+46,"vga_ball sp4 state_next",-1,31,0);
    }
}

void Vvga_ball::traceFullThis__1(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->fullBus  (c+1,(vlTOPp->vga_ball__DOT__sprite_base_addr[0]),5);
	vcdp->fullBus  (c+2,(vlTOPp->vga_ball__DOT__sprite_base_addr[1]),5);
	vcdp->fullBus  (c+3,(vlTOPp->vga_ball__DOT__sprite_base_addr[2]),5);
	vcdp->fullBus  (c+4,(vlTOPp->vga_ball__DOT__sprite_base_addr[3]),5);
	vcdp->fullBus  (c+5,(vlTOPp->vga_ball__DOT__sprite_base_addr[4]),5);
	vcdp->fullBus  (c+6,(vlTOPp->vga_ball__DOT__h_start[0]),11);
	vcdp->fullBus  (c+7,(vlTOPp->vga_ball__DOT__h_start[1]),11);
	vcdp->fullBus  (c+8,(vlTOPp->vga_ball__DOT__h_start[2]),11);
	vcdp->fullBus  (c+9,(vlTOPp->vga_ball__DOT__h_start[3]),11);
	vcdp->fullBus  (c+10,(vlTOPp->vga_ball__DOT__h_start[4]),11);
	vcdp->fullBus  (c+11,(vlTOPp->vga_ball__DOT__h_start
			      [0U]),11);
	vcdp->fullBus  (c+12,(vlTOPp->vga_ball__DOT__sprite_base_addr
			      [0U]),5);
	vcdp->fullBus  (c+13,(vlTOPp->vga_ball__DOT__h_start
			      [1U]),11);
	vcdp->fullBus  (c+14,(vlTOPp->vga_ball__DOT__sprite_base_addr
			      [1U]),5);
	vcdp->fullBus  (c+15,(vlTOPp->vga_ball__DOT__h_start
			      [2U]),11);
	vcdp->fullBus  (c+16,(vlTOPp->vga_ball__DOT__sprite_base_addr
			      [2U]),5);
	vcdp->fullBus  (c+17,(vlTOPp->vga_ball__DOT__h_start
			      [3U]),11);
	vcdp->fullBus  (c+18,(vlTOPp->vga_ball__DOT__sprite_base_addr
			      [3U]),5);
	vcdp->fullBus  (c+19,(vlTOPp->vga_ball__DOT__h_start
			      [4U]),11);
	vcdp->fullBus  (c+20,(vlTOPp->vga_ball__DOT__sprite_base_addr
			      [4U]),5);
	vcdp->fullBus  (c+21,(vlTOPp->vga_ball__DOT__out_pixel[0]),4);
	vcdp->fullBus  (c+22,(vlTOPp->vga_ball__DOT__out_pixel[1]),4);
	vcdp->fullBus  (c+23,(vlTOPp->vga_ball__DOT__out_pixel[2]),4);
	vcdp->fullBus  (c+24,(vlTOPp->vga_ball__DOT__out_pixel[3]),4);
	vcdp->fullBus  (c+25,(vlTOPp->vga_ball__DOT__out_pixel[4]),4);
	vcdp->fullBus  (c+26,(vlTOPp->vga_ball__DOT__out_pixel[5]),4);
	vcdp->fullBus  (c+27,(vlTOPp->vga_ball__DOT__final_out_pixel),4);
	vcdp->fullBus  (c+28,(vlTOPp->vga_ball__DOT__rgb_val),24);
	vcdp->fullBus  (c+29,(vlTOPp->vga_ball__DOT__sprite_ra_a[0]),5);
	vcdp->fullBus  (c+30,(vlTOPp->vga_ball__DOT__sprite_ra_a[1]),5);
	vcdp->fullBus  (c+31,(vlTOPp->vga_ball__DOT__sprite_ra_a[2]),5);
	vcdp->fullBus  (c+32,(vlTOPp->vga_ball__DOT__sprite_ra_a[3]),5);
	vcdp->fullBus  (c+33,(vlTOPp->vga_ball__DOT__sprite_ra_a[4]),5);
	vcdp->fullBus  (c+34,(vlTOPp->vga_ball__DOT__sprite_ra_g[0]),11);
	vcdp->fullBus  (c+35,(vlTOPp->vga_ball__DOT__sprite_ra_g[1]),11);
	vcdp->fullBus  (c+36,(vlTOPp->vga_ball__DOT__sprite_ra_g[2]),11);
	vcdp->fullBus  (c+37,(vlTOPp->vga_ball__DOT__sprite_ra_g[3]),11);
	vcdp->fullBus  (c+38,(vlTOPp->vga_ball__DOT__sprite_ra_g[4]),11);
	vcdp->fullBus  (c+39,(vlTOPp->vga_ball__DOT__ra_a),5);
	vcdp->fullBus  (c+40,(vlTOPp->vga_ball__DOT__ra_g),11);
	vcdp->fullBus  (c+41,(vlTOPp->vga_ball__DOT__pp0__DOT__state_next),32);
	vcdp->fullBus  (c+42,(vlTOPp->vga_ball__DOT__sp0__DOT__state_next),32);
	vcdp->fullBus  (c+43,(vlTOPp->vga_ball__DOT__sp1__DOT__state_next),32);
	vcdp->fullBus  (c+44,(vlTOPp->vga_ball__DOT__sp2__DOT__state_next),32);
	vcdp->fullBus  (c+45,(vlTOPp->vga_ball__DOT__sp3__DOT__state_next),32);
	vcdp->fullBus  (c+46,(vlTOPp->vga_ball__DOT__sp4__DOT__state_next),32);
	vcdp->fullBus  (c+47,(vlTOPp->vga_ball__DOT__background_r),8);
	vcdp->fullBus  (c+48,(vlTOPp->vga_ball__DOT__background_g),8);
	vcdp->fullBus  (c+49,(vlTOPp->vga_ball__DOT__background_b),8);
	vcdp->fullBus  (c+50,(vlTOPp->vga_ball__DOT__ra_n),12);
	vcdp->fullBus  (c+51,(vlTOPp->vga_ball__DOT__wa_n),12);
	vcdp->fullBit  (c+52,(vlTOPp->vga_ball__DOT__we_n));
	vcdp->fullBus  (c+53,(vlTOPp->vga_ball__DOT__din_n),8);
	vcdp->fullBus  (c+54,(vlTOPp->vga_ball__DOT__dout_n),8);
	vcdp->fullBus  (c+55,(vlTOPp->vga_ball__DOT__ra_pg),11);
	vcdp->fullBus  (c+56,(vlTOPp->vga_ball__DOT__wa_pg),11);
	vcdp->fullBit  (c+57,(vlTOPp->vga_ball__DOT__we_pg));
	vcdp->fullBus  (c+58,(vlTOPp->vga_ball__DOT__din_pg),8);
	vcdp->fullBus  (c+59,(vlTOPp->vga_ball__DOT__dout_pg),8);
	vcdp->fullBus  (c+60,(vlTOPp->vga_ball__DOT__wa_a),5);
	vcdp->fullBit  (c+61,(vlTOPp->vga_ball__DOT__we_a));
	vcdp->fullBus  (c+62,(vlTOPp->vga_ball__DOT__din_a),8);
	vcdp->fullBus  (c+63,(vlTOPp->vga_ball__DOT__dout_a),8);
	vcdp->fullBus  (c+64,(vlTOPp->vga_ball__DOT__wa_g),11);
	vcdp->fullBit  (c+65,(vlTOPp->vga_ball__DOT__we_g));
	vcdp->fullBus  (c+66,(vlTOPp->vga_ball__DOT__din_g),8);
	vcdp->fullBus  (c+67,(vlTOPp->vga_ball__DOT__dout_g),8);
	vcdp->fullBus  (c+68,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[0]),8);
	vcdp->fullBus  (c+69,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[1]),8);
	vcdp->fullBus  (c+70,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[2]),8);
	vcdp->fullBus  (c+71,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[3]),8);
	vcdp->fullBus  (c+72,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[4]),8);
	vcdp->fullBus  (c+73,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[5]),8);
	vcdp->fullBus  (c+74,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[6]),8);
	vcdp->fullBus  (c+75,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[7]),8);
	vcdp->fullBus  (c+76,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[8]),8);
	vcdp->fullBus  (c+77,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[9]),8);
	vcdp->fullBus  (c+78,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[10]),8);
	vcdp->fullBus  (c+79,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[11]),8);
	vcdp->fullBus  (c+80,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[12]),8);
	vcdp->fullBus  (c+81,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[13]),8);
	vcdp->fullBus  (c+82,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[14]),8);
	vcdp->fullBus  (c+83,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[15]),8);
	vcdp->fullBus  (c+84,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[16]),8);
	vcdp->fullBus  (c+85,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[17]),8);
	vcdp->fullBus  (c+86,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[18]),8);
	vcdp->fullBus  (c+87,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[19]),8);
	vcdp->fullBus  (c+88,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[20]),8);
	vcdp->fullBus  (c+89,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[21]),8);
	vcdp->fullBus  (c+90,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[22]),8);
	vcdp->fullBus  (c+91,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[23]),8);
	vcdp->fullBus  (c+92,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[24]),8);
	vcdp->fullBus  (c+93,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[25]),8);
	vcdp->fullBus  (c+94,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[26]),8);
	vcdp->fullBus  (c+95,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[27]),8);
	vcdp->fullBus  (c+96,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[28]),8);
	vcdp->fullBus  (c+97,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[29]),8);
	vcdp->fullBus  (c+98,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[30]),8);
	vcdp->fullBus  (c+99,(vlTOPp->vga_ball__DOT__sat1__DOT__mem[31]),8);
	vcdp->fullBus  (c+100,((0xfU & vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0U])),4);
	vcdp->fullArray(c+101,(vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg),2048);
	vcdp->fullBus  (c+165,(vlTOPp->vga_ball__DOT__pp0__DOT__shift_pos),12);
	vcdp->fullBus  (c+166,(vlTOPp->vga_ball__DOT__pp0__DOT__pattern_row_offset),11);
	vcdp->fullArray(c+167,(vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel),2048);
	vcdp->fullBus  (c+231,(vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg_shift),12);
	vcdp->fullBus  (c+232,(vlTOPp->vga_ball__DOT__pp0__DOT__tile_total_counter),8);
	vcdp->fullBus  (c+233,(vlTOPp->vga_ball__DOT__pp0__DOT__tile_pixel_counter),8);
	vcdp->fullBus  (c+234,(vlTOPp->vga_ball__DOT__pp0__DOT__state),32);
	vcdp->fullBus  (c+235,(vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_a),5);
	vcdp->fullBus  (c+236,(vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_g),11);
	vcdp->fullBus  (c+237,((0xfU & (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__display_pixel))),4);
	vcdp->fullBus  (c+238,(vlTOPp->vga_ball__DOT__sp0__DOT__down_counter),9);
	vcdp->fullQuad (c+239,(vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg),64);
	vcdp->fullBus  (c+241,(vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos),8);
	vcdp->fullBus  (c+242,(vlTOPp->vga_ball__DOT__sp0__DOT__sprite_offset),11);
	vcdp->fullQuad (c+243,(vlTOPp->vga_ball__DOT__sp0__DOT__display_pixel),64);
	vcdp->fullBus  (c+245,(vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift),8);
	vcdp->fullBus  (c+246,(vlTOPp->vga_ball__DOT__sp0__DOT__state),32);
	vcdp->fullBus  (c+247,(vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_a),5);
	vcdp->fullBus  (c+248,(vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_g),11);
	vcdp->fullBus  (c+249,((0xfU & (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__display_pixel))),4);
	vcdp->fullBus  (c+250,(vlTOPp->vga_ball__DOT__sp1__DOT__down_counter),9);
	vcdp->fullQuad (c+251,(vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg),64);
	vcdp->fullBus  (c+253,(vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos),8);
	vcdp->fullBus  (c+254,(vlTOPp->vga_ball__DOT__sp1__DOT__sprite_offset),11);
	vcdp->fullQuad (c+255,(vlTOPp->vga_ball__DOT__sp1__DOT__display_pixel),64);
	vcdp->fullBus  (c+257,(vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift),8);
	vcdp->fullBus  (c+258,(vlTOPp->vga_ball__DOT__sp1__DOT__state),32);
	vcdp->fullBus  (c+259,(vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_a),5);
	vcdp->fullBus  (c+260,(vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_g),11);
	vcdp->fullBus  (c+261,((0xfU & (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__display_pixel))),4);
	vcdp->fullBus  (c+262,(vlTOPp->vga_ball__DOT__sp2__DOT__down_counter),9);
	vcdp->fullQuad (c+263,(vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg),64);
	vcdp->fullBus  (c+265,(vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos),8);
	vcdp->fullBus  (c+266,(vlTOPp->vga_ball__DOT__sp2__DOT__sprite_offset),11);
	vcdp->fullQuad (c+267,(vlTOPp->vga_ball__DOT__sp2__DOT__display_pixel),64);
	vcdp->fullBus  (c+269,(vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift),8);
	vcdp->fullBus  (c+270,(vlTOPp->vga_ball__DOT__sp2__DOT__state),32);
	vcdp->fullBus  (c+271,(vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_a),5);
	vcdp->fullBus  (c+272,(vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_g),11);
	vcdp->fullBus  (c+273,((0xfU & (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__display_pixel))),4);
	vcdp->fullBus  (c+274,(vlTOPp->vga_ball__DOT__sp3__DOT__down_counter),9);
	vcdp->fullQuad (c+275,(vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg),64);
	vcdp->fullBus  (c+277,(vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos),8);
	vcdp->fullBus  (c+278,(vlTOPp->vga_ball__DOT__sp3__DOT__sprite_offset),11);
	vcdp->fullQuad (c+279,(vlTOPp->vga_ball__DOT__sp3__DOT__display_pixel),64);
	vcdp->fullBus  (c+281,(vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift),8);
	vcdp->fullBus  (c+282,(vlTOPp->vga_ball__DOT__sp3__DOT__state),32);
	vcdp->fullBus  (c+283,(vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_a),5);
	vcdp->fullBus  (c+284,(vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_g),11);
	vcdp->fullBus  (c+285,((0xfU & (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__display_pixel))),4);
	vcdp->fullBus  (c+286,(vlTOPp->vga_ball__DOT__sp4__DOT__down_counter),9);
	vcdp->fullQuad (c+287,(vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg),64);
	vcdp->fullBus  (c+289,(vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos),8);
	vcdp->fullBus  (c+290,(vlTOPp->vga_ball__DOT__sp4__DOT__sprite_offset),11);
	vcdp->fullQuad (c+291,(vlTOPp->vga_ball__DOT__sp4__DOT__display_pixel),64);
	vcdp->fullBus  (c+293,(vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift),8);
	vcdp->fullBus  (c+294,(vlTOPp->vga_ball__DOT__sp4__DOT__state),32);
	vcdp->fullBus  (c+295,(vlTOPp->vga_ball__DOT__hcount),11);
	vcdp->fullBus  (c+296,(vlTOPp->vga_ball__DOT__vcount),10);
	vcdp->fullBit  (c+297,((0x63fU == (IData)(vlTOPp->vga_ball__DOT__hcount))));
	vcdp->fullBit  (c+298,((0x20cU == (IData)(vlTOPp->vga_ball__DOT__vcount))));
	vcdp->fullBit  (c+299,(vlTOPp->clk));
	vcdp->fullBit  (c+300,(vlTOPp->reset));
	vcdp->fullBus  (c+301,(vlTOPp->writedata),32);
	vcdp->fullBit  (c+302,(vlTOPp->write));
	vcdp->fullBit  (c+303,(vlTOPp->chipselect));
	vcdp->fullBus  (c+304,(vlTOPp->address),4);
	vcdp->fullBus  (c+305,(vlTOPp->VGA_R),8);
	vcdp->fullBus  (c+306,(vlTOPp->VGA_G),8);
	vcdp->fullBus  (c+307,(vlTOPp->VGA_B),8);
	vcdp->fullBit  (c+308,(vlTOPp->VGA_CLK));
	vcdp->fullBit  (c+309,(vlTOPp->VGA_HS));
	vcdp->fullBit  (c+310,(vlTOPp->VGA_VS));
	vcdp->fullBit  (c+311,(vlTOPp->VGA_BLANK_n));
	vcdp->fullBit  (c+312,(vlTOPp->VGA_SYNC_n));
	vcdp->fullBus  (c+313,(0x500U),11);
	vcdp->fullBus  (c+314,(0x20U),11);
	vcdp->fullBus  (c+315,(0xc0U),11);
	vcdp->fullBus  (c+316,(0x60U),11);
	vcdp->fullBus  (c+317,(0x640U),11);
	vcdp->fullBus  (c+318,(0x1e0U),10);
	vcdp->fullBus  (c+319,(0xaU),10);
	vcdp->fullBus  (c+320,(2U),10);
	vcdp->fullBus  (c+321,(0x21U),10);
	vcdp->fullBus  (c+322,(0x20dU),10);
	vcdp->fullBus  (c+323,(0U),12);
	vcdp->fullBus  (c+324,(0x40U),8);
	vcdp->fullBus  (c+325,(0xfc0U),12);
    }
}
