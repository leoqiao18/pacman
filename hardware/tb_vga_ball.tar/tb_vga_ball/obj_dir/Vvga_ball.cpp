// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vvga_ball.h for the primary calling header

#include "Vvga_ball.h"         // For This
#include "Vvga_ball__Syms.h"


//--------------------
// STATIC VARIABLES

VL_ST_SIG(Vvga_ball::__Vtable1_vga_ball__DOT__rgb_val[16],23,0);

//--------------------

VL_CTOR_IMP(Vvga_ball) {
    Vvga_ball__Syms* __restrict vlSymsp = __VlSymsp = new Vvga_ball__Syms(this, name());
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Reset internal values
    
    // Reset structure values
    _ctor_var_reset();
}

void Vvga_ball::__Vconfigure(Vvga_ball__Syms* vlSymsp, bool first) {
    if (0 && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
}

Vvga_ball::~Vvga_ball() {
    delete __VlSymsp; __VlSymsp=NULL;
}

//--------------------


void Vvga_ball::eval() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vvga_ball::eval\n"); );
    Vvga_ball__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
	VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
	vlSymsp->__Vm_activity = true;
	_eval(vlSymsp);
	if (VL_UNLIKELY(++__VclockLoop > 100)) {
	    // About to fail, so enable debug to see what's not settling.
	    // Note you must run make with OPT=-DVL_DEBUG for debug prints.
	    int __Vsaved_debug = Verilated::debug();
	    Verilated::debug(1);
	    __Vchange = _change_request(vlSymsp);
	    Verilated::debug(__Vsaved_debug);
	    VL_FATAL_MT(__FILE__,__LINE__,__FILE__,"Verilated model didn't converge");
	} else {
	    __Vchange = _change_request(vlSymsp);
	}
    } while (VL_UNLIKELY(__Vchange));
}

void Vvga_ball::_eval_initial_loop(Vvga_ball__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
	_eval_settle(vlSymsp);
	_eval(vlSymsp);
	if (VL_UNLIKELY(++__VclockLoop > 100)) {
	    // About to fail, so enable debug to see what's not settling.
	    // Note you must run make with OPT=-DVL_DEBUG for debug prints.
	    int __Vsaved_debug = Verilated::debug();
	    Verilated::debug(1);
	    __Vchange = _change_request(vlSymsp);
	    Verilated::debug(__Vsaved_debug);
	    VL_FATAL_MT(__FILE__,__LINE__,__FILE__,"Verilated model didn't DC converge");
	} else {
	    __Vchange = _change_request(vlSymsp);
	}
    } while (VL_UNLIKELY(__Vchange));
}

//--------------------
// Internal Methods

void Vvga_ball::_initial__TOP__1(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_initial__TOP__1\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // INITIAL at vga_ball.sv:526
    vlTOPp->VGA_SYNC_n = 0U;
}

void Vvga_ball::_settle__TOP__2(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_settle__TOP__2\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->vga_ball__DOT__h_start[0U] = 0x520U;
    vlTOPp->vga_ball__DOT__h_start[1U] = 0x53aU;
    vlTOPp->vga_ball__DOT__h_start[2U] = 0x554U;
    vlTOPp->vga_ball__DOT__h_start[3U] = 0x56eU;
    vlTOPp->vga_ball__DOT__h_start[4U] = 0x588U;
    vlTOPp->vga_ball__DOT__sprite_base_addr[0U] = 0U;
    vlTOPp->vga_ball__DOT__sprite_base_addr[1U] = 4U;
    vlTOPp->vga_ball__DOT__sprite_base_addr[2U] = 8U;
    vlTOPp->vga_ball__DOT__sprite_base_addr[3U] = 0xcU;
    vlTOPp->vga_ball__DOT__sprite_base_addr[4U] = 0x10U;
    vlTOPp->vga_ball__DOT__counters__DOT__endOfLine 
	= (0x63fU == (IData)(vlTOPp->vga_ball__DOT__hcount));
    vlTOPp->vga_ball__DOT__counters__DOT__endOfField 
	= (0x20cU == (IData)(vlTOPp->vga_ball__DOT__vcount));
    vlTOPp->VGA_HS = (1U & (~ ((5U == (7U & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
					     >> 8U))) 
			       & (7U != (7U & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
					       >> 5U))))));
    vlTOPp->VGA_VS = (0xf5U != (0x1ffU & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
					  >> 1U)));
    vlTOPp->VGA_CLK = (1U & (IData)(vlTOPp->vga_ball__DOT__hcount));
    // ALWAYS at vga_ball.sv:368
    vlTOPp->vga_ball__DOT__pp0__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__pp0__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						     | (7U 
							== vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						    | (8U 
						       == vlTOPp->vga_ball__DOT__pp0__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						     ? 
						    ((0x520U 
						      == (IData)(vlTOPp->vga_ball__DOT__hcount))
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__pp0__DOT__state)
						        ? 4U
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__pp0__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__pp0__DOT__state)
							  ? 
							 ((3U 
							   == (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__tile_pixel_counter))
							   ? 7U
							   : 5U)
							  : 
							 ((7U 
							   == vlTOPp->vga_ball__DOT__pp0__DOT__state)
							   ? 8U
							   : 
							  ((0x40U 
							    == (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__tile_total_counter))
							    ? 9U
							    : 3U))))))))
						    : 
						   ((9U 
						     == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						     ? 
						    ((0x40U 
						      == (IData)(vlTOPp->vga_ball__DOT__hcount))
						      ? 0xaU
						      : 9U)
						     : 
						    ((0xaU 
						      == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						      ? 
						     ((0U 
						       == (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__shift_pos))
						       ? 0U
						       : 0xaU)
						      : 0U)));
    vlTOPp->vga_ball__DOT__sprite_ra_g[0U] = vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[0U] = vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_a;
    vlTOPp->vga_ball__DOT__sprite_ra_g[1U] = vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[1U] = vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_a;
    vlTOPp->vga_ball__DOT__sprite_ra_g[2U] = vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[2U] = vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_a;
    vlTOPp->vga_ball__DOT__sprite_ra_g[3U] = vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[3U] = vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_a;
    vlTOPp->vga_ball__DOT__sprite_ra_g[4U] = vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[4U] = vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_a;
    vlTOPp->VGA_BLANK_n = (1U & ((~ (((IData)(vlTOPp->vga_ball__DOT__hcount) 
				      >> 0xaU) & (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						   >> 9U) 
						  | ((IData)(vlTOPp->vga_ball__DOT__hcount) 
						     >> 8U)))) 
				 & (~ (((IData)(vlTOPp->vga_ball__DOT__vcount) 
					>> 9U) | (0xfU 
						  == 
						  (0xfU 
						   & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
						      >> 5U)))))));
    vlTOPp->vga_ball__DOT__out_pixel[5U] = (0xfU & 
					    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0U]);
    vlTOPp->vga_ball__DOT__out_pixel[0U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__out_pixel[1U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__out_pixel[2U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__out_pixel[3U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__out_pixel[4U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__display_pixel));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp0__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp0__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [0U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp0__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp0__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp1__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp1__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [1U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp1__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp1__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp2__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp2__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [2U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp2__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp2__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp3__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp3__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [3U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp3__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp3__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp4__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp4__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [4U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp4__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp4__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:163
    if ((((IData)(vlTOPp->vga_ball__DOT__hcount) >= 
	  vlTOPp->vga_ball__DOT__h_start[0U]) & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
						 < 
						 vlTOPp->vga_ball__DOT__h_start
						 [1U]))) {
	vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
	    [0U];
	vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
	    [0U];
    } else {
	if ((((IData)(vlTOPp->vga_ball__DOT__hcount) 
	      >= vlTOPp->vga_ball__DOT__h_start[1U]) 
	     & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
		< vlTOPp->vga_ball__DOT__h_start[2U]))) {
	    vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
		[1U];
	    vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
		[1U];
	} else {
	    if ((((IData)(vlTOPp->vga_ball__DOT__hcount) 
		  >= vlTOPp->vga_ball__DOT__h_start
		  [2U]) & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
			   < vlTOPp->vga_ball__DOT__h_start
			   [3U]))) {
		vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
		    [2U];
		vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
		    [2U];
	    } else {
		if ((((IData)(vlTOPp->vga_ball__DOT__hcount) 
		      >= vlTOPp->vga_ball__DOT__h_start
		      [3U]) & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
			       < vlTOPp->vga_ball__DOT__h_start
			       [4U]))) {
		    vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
			[3U];
		    vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
			[3U];
		} else {
		    if (((IData)(vlTOPp->vga_ball__DOT__hcount) 
			 >= vlTOPp->vga_ball__DOT__h_start
			 [4U])) {
			vlTOPp->vga_ball__DOT__ra_a 
			    = vlTOPp->vga_ball__DOT__sprite_ra_a
			    [4U];
			vlTOPp->vga_ball__DOT__ra_g 
			    = vlTOPp->vga_ball__DOT__sprite_ra_g
			    [4U];
		    } else {
			vlTOPp->vga_ball__DOT__ra_a = 0U;
			vlTOPp->vga_ball__DOT__ra_g = 0U;
		    }
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:151
    vlTOPp->vga_ball__DOT__final_out_pixel = ((0U != 
					       vlTOPp->vga_ball__DOT__out_pixel
					       [0U])
					       ? vlTOPp->vga_ball__DOT__out_pixel
					      [0U] : 
					      ((0U 
						!= 
						vlTOPp->vga_ball__DOT__out_pixel
						[1U])
					        ? vlTOPp->vga_ball__DOT__out_pixel
					       [1U]
					        : (
						   (0U 
						    != 
						    vlTOPp->vga_ball__DOT__out_pixel
						    [2U])
						    ? 
						   vlTOPp->vga_ball__DOT__out_pixel
						   [2U]
						    : 
						   ((0U 
						     != 
						     vlTOPp->vga_ball__DOT__out_pixel
						     [3U])
						     ? 
						    vlTOPp->vga_ball__DOT__out_pixel
						    [3U]
						     : 
						    ((0U 
						      != 
						      vlTOPp->vga_ball__DOT__out_pixel
						      [4U])
						      ? 
						     vlTOPp->vga_ball__DOT__out_pixel
						     [4U]
						      : 
						     ((0U 
						       != 
						       vlTOPp->vga_ball__DOT__out_pixel
						       [5U])
						       ? 
						      vlTOPp->vga_ball__DOT__out_pixel
						      [5U]
						       : 0U))))));
    // ALWAYS at vga_ball.sv:450
    vlTOPp->__Vtableidx1 = vlTOPp->vga_ball__DOT__final_out_pixel;
    vlTOPp->vga_ball__DOT__rgb_val = vlTOPp->__Vtable1_vga_ball__DOT__rgb_val
	[vlTOPp->__Vtableidx1];
    // ALWAYS at vga_ball.sv:143
    vlTOPp->VGA_R = 0U;
    vlTOPp->VGA_G = 0U;
    vlTOPp->VGA_B = 0U;
    if (vlTOPp->VGA_BLANK_n) {
	if ((0U != (IData)(vlTOPp->vga_ball__DOT__final_out_pixel))) {
	    vlTOPp->VGA_R = (0xffU & (vlTOPp->vga_ball__DOT__rgb_val 
				      >> 0x10U));
	    vlTOPp->VGA_G = (0xffU & (vlTOPp->vga_ball__DOT__rgb_val 
				      >> 8U));
	    vlTOPp->VGA_B = (0xffU & vlTOPp->vga_ball__DOT__rgb_val);
	} else {
	    vlTOPp->VGA_R = vlTOPp->vga_ball__DOT__background_r;
	    vlTOPp->VGA_G = vlTOPp->vga_ball__DOT__background_g;
	    vlTOPp->VGA_B = vlTOPp->vga_ball__DOT__background_b;
	}
    }
}

VL_INLINE_OPT void Vvga_ball::_sequent__TOP__3(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_sequent__TOP__3\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    VL_SIG8(__Vdlyvval__vga_ball__DOT__pn1__DOT__mem__v0,7,0);
    VL_SIG8(__Vdlyvset__vga_ball__DOT__pn1__DOT__mem__v0,0,0);
    VL_SIG8(__Vdlyvval__vga_ball__DOT__pg1__DOT__mem__v0,7,0);
    VL_SIG8(__Vdlyvset__vga_ball__DOT__pg1__DOT__mem__v0,0,0);
    VL_SIG8(__Vdlyvdim0__vga_ball__DOT__sat1__DOT__mem__v0,4,0);
    VL_SIG8(__Vdlyvval__vga_ball__DOT__sat1__DOT__mem__v0,7,0);
    VL_SIG8(__Vdlyvset__vga_ball__DOT__sat1__DOT__mem__v0,0,0);
    VL_SIG8(__Vdlyvval__vga_ball__DOT__sgt1__DOT__mem__v0,7,0);
    VL_SIG8(__Vdlyvset__vga_ball__DOT__sgt1__DOT__mem__v0,0,0);
    VL_SIG8(__Vdly__vga_ball__DOT__pp0__DOT__tile_total_counter,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__pp0__DOT__tile_pixel_counter,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp0__DOT__shift_reg_shift,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp0__DOT__shift_pos,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp1__DOT__shift_reg_shift,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp1__DOT__shift_pos,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp2__DOT__shift_reg_shift,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp2__DOT__shift_pos,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp3__DOT__shift_reg_shift,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp3__DOT__shift_pos,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp4__DOT__shift_reg_shift,7,0);
    VL_SIG8(__Vdly__vga_ball__DOT__sp4__DOT__shift_pos,7,0);
    VL_SIG16(__Vdlyvdim0__vga_ball__DOT__pn1__DOT__mem__v0,11,0);
    VL_SIG16(__Vdlyvdim0__vga_ball__DOT__pg1__DOT__mem__v0,10,0);
    VL_SIG16(__Vdlyvdim0__vga_ball__DOT__sgt1__DOT__mem__v0,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__ra_n,11,0);
    VL_SIG16(__Vdly__vga_ball__DOT__ra_pg,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__pp0__DOT__shift_reg_shift,11,0);
    VL_SIG16(__Vdly__vga_ball__DOT__pp0__DOT__shift_pos,11,0);
    VL_SIG16(__Vdly__vga_ball__DOT__pp0__DOT__pattern_row_offset,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT____Vcellout__sp0__ra_g,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp0__DOT__sprite_offset,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp0__DOT__down_counter,8,0);
    VL_SIG16(__Vdly__vga_ball__DOT____Vcellout__sp1__ra_g,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp1__DOT__sprite_offset,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp1__DOT__down_counter,8,0);
    VL_SIG16(__Vdly__vga_ball__DOT____Vcellout__sp2__ra_g,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp2__DOT__sprite_offset,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp2__DOT__down_counter,8,0);
    VL_SIG16(__Vdly__vga_ball__DOT____Vcellout__sp3__ra_g,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp3__DOT__sprite_offset,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp3__DOT__down_counter,8,0);
    VL_SIG16(__Vdly__vga_ball__DOT____Vcellout__sp4__ra_g,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp4__DOT__sprite_offset,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__sp4__DOT__down_counter,8,0);
    VL_SIG(__Vdly__vga_ball__DOT__pp0__DOT__state,31,0);
    VL_SIGW(__Vdly__vga_ball__DOT__pp0__DOT__shift_reg,2047,0,64);
    VL_SIG(__Vdly__vga_ball__DOT__sp0__DOT__state,31,0);
    VL_SIG(__Vdly__vga_ball__DOT__sp1__DOT__state,31,0);
    VL_SIG(__Vdly__vga_ball__DOT__sp2__DOT__state,31,0);
    VL_SIG(__Vdly__vga_ball__DOT__sp3__DOT__state,31,0);
    VL_SIG(__Vdly__vga_ball__DOT__sp4__DOT__state,31,0);
    VL_SIGW(__Vtemp1,2047,0,64);
    VL_SIGW(__Vtemp2,2047,0,64);
    VL_SIGW(__Vtemp4,2047,0,64);
    VL_SIG64(__Vdly__vga_ball__DOT__sp0__DOT__shift_reg,63,0);
    VL_SIG64(__Vdly__vga_ball__DOT__sp1__DOT__shift_reg,63,0);
    VL_SIG64(__Vdly__vga_ball__DOT__sp2__DOT__shift_reg,63,0);
    VL_SIG64(__Vdly__vga_ball__DOT__sp3__DOT__shift_reg,63,0);
    VL_SIG64(__Vdly__vga_ball__DOT__sp4__DOT__shift_reg,63,0);
    // Body
    __Vdlyvset__vga_ball__DOT__pn1__DOT__mem__v0 = 0U;
    __Vdlyvset__vga_ball__DOT__pg1__DOT__mem__v0 = 0U;
    __Vdlyvset__vga_ball__DOT__sat1__DOT__mem__v0 = 0U;
    __Vdlyvset__vga_ball__DOT__sgt1__DOT__mem__v0 = 0U;
    __Vdly__vga_ball__DOT__ra_n = vlTOPp->vga_ball__DOT__ra_n;
    __Vdly__vga_ball__DOT__ra_pg = vlTOPp->vga_ball__DOT__ra_pg;
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[1U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[1U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[2U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[2U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[3U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[3U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[4U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[4U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[5U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[5U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[6U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[6U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[7U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[7U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[8U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[8U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[9U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[9U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xaU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xaU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xbU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xbU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xcU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xcU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xdU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xdU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xeU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xeU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xfU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xfU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x10U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x10U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x11U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x11U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x12U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x12U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x13U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x13U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x14U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x14U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x15U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x15U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x16U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x16U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x17U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x17U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x18U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x18U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x19U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x19U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1aU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1aU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1bU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1bU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1cU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1cU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1dU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1dU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1eU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1eU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1fU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1fU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x20U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x20U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x21U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x21U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x22U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x22U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x23U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x23U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x24U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x24U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x25U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x25U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x26U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x26U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x27U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x27U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x28U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x28U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x29U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x29U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2aU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2aU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2bU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2bU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2cU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2cU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2dU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2dU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2eU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2eU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2fU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2fU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x30U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x30U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x31U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x31U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x32U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x32U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x33U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x33U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x34U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x34U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x35U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x35U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x36U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x36U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x37U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x37U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x38U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x38U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x39U] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x39U];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3aU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3aU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3bU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3bU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3cU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3cU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3dU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3dU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3eU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3eU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3fU] 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3fU];
    __Vdly__vga_ball__DOT__pp0__DOT__shift_reg_shift 
	= vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg_shift;
    __Vdly__vga_ball__DOT__pp0__DOT__pattern_row_offset 
	= vlTOPp->vga_ball__DOT__pp0__DOT__pattern_row_offset;
    __Vdly__vga_ball__DOT__pp0__DOT__state = vlTOPp->vga_ball__DOT__pp0__DOT__state;
    __Vdly__vga_ball__DOT__pp0__DOT__tile_total_counter 
	= vlTOPp->vga_ball__DOT__pp0__DOT__tile_total_counter;
    __Vdly__vga_ball__DOT__pp0__DOT__tile_pixel_counter 
	= vlTOPp->vga_ball__DOT__pp0__DOT__tile_pixel_counter;
    __Vdly__vga_ball__DOT__pp0__DOT__shift_pos = vlTOPp->vga_ball__DOT__pp0__DOT__shift_pos;
    __Vdly__vga_ball__DOT__sp0__DOT__shift_reg = vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg;
    __Vdly__vga_ball__DOT__sp0__DOT__sprite_offset 
	= vlTOPp->vga_ball__DOT__sp0__DOT__sprite_offset;
    __Vdly__vga_ball__DOT__sp1__DOT__shift_reg = vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg;
    __Vdly__vga_ball__DOT__sp1__DOT__sprite_offset 
	= vlTOPp->vga_ball__DOT__sp1__DOT__sprite_offset;
    __Vdly__vga_ball__DOT__sp2__DOT__shift_reg = vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg;
    __Vdly__vga_ball__DOT__sp2__DOT__sprite_offset 
	= vlTOPp->vga_ball__DOT__sp2__DOT__sprite_offset;
    __Vdly__vga_ball__DOT__sp3__DOT__shift_reg = vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg;
    __Vdly__vga_ball__DOT__sp3__DOT__sprite_offset 
	= vlTOPp->vga_ball__DOT__sp3__DOT__sprite_offset;
    __Vdly__vga_ball__DOT__sp4__DOT__shift_reg = vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg;
    __Vdly__vga_ball__DOT__sp4__DOT__sprite_offset 
	= vlTOPp->vga_ball__DOT__sp4__DOT__sprite_offset;
    __Vdly__vga_ball__DOT__sp0__DOT__state = vlTOPp->vga_ball__DOT__sp0__DOT__state;
    __Vdly__vga_ball__DOT__sp0__DOT__shift_reg_shift 
	= vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift;
    __Vdly__vga_ball__DOT__sp0__DOT__shift_pos = vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos;
    __Vdly__vga_ball__DOT__sp0__DOT__down_counter = vlTOPp->vga_ball__DOT__sp0__DOT__down_counter;
    __Vdly__vga_ball__DOT__sp1__DOT__state = vlTOPp->vga_ball__DOT__sp1__DOT__state;
    __Vdly__vga_ball__DOT__sp1__DOT__shift_reg_shift 
	= vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift;
    __Vdly__vga_ball__DOT__sp1__DOT__shift_pos = vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos;
    __Vdly__vga_ball__DOT__sp1__DOT__down_counter = vlTOPp->vga_ball__DOT__sp1__DOT__down_counter;
    __Vdly__vga_ball__DOT__sp2__DOT__state = vlTOPp->vga_ball__DOT__sp2__DOT__state;
    __Vdly__vga_ball__DOT__sp2__DOT__shift_reg_shift 
	= vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift;
    __Vdly__vga_ball__DOT__sp2__DOT__shift_pos = vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos;
    __Vdly__vga_ball__DOT__sp2__DOT__down_counter = vlTOPp->vga_ball__DOT__sp2__DOT__down_counter;
    __Vdly__vga_ball__DOT__sp3__DOT__state = vlTOPp->vga_ball__DOT__sp3__DOT__state;
    __Vdly__vga_ball__DOT__sp3__DOT__shift_reg_shift 
	= vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift;
    __Vdly__vga_ball__DOT__sp3__DOT__shift_pos = vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos;
    __Vdly__vga_ball__DOT__sp3__DOT__down_counter = vlTOPp->vga_ball__DOT__sp3__DOT__down_counter;
    __Vdly__vga_ball__DOT__sp4__DOT__state = vlTOPp->vga_ball__DOT__sp4__DOT__state;
    __Vdly__vga_ball__DOT__sp4__DOT__shift_reg_shift 
	= vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift;
    __Vdly__vga_ball__DOT__sp4__DOT__shift_pos = vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos;
    __Vdly__vga_ball__DOT__sp4__DOT__down_counter = vlTOPp->vga_ball__DOT__sp4__DOT__down_counter;
    __Vdly__vga_ball__DOT____Vcellout__sp0__ra_g = vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_g;
    __Vdly__vga_ball__DOT____Vcellout__sp1__ra_g = vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_g;
    __Vdly__vga_ball__DOT____Vcellout__sp2__ra_g = vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_g;
    __Vdly__vga_ball__DOT____Vcellout__sp3__ra_g = vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_g;
    __Vdly__vga_ball__DOT____Vcellout__sp4__ra_g = vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_g;
    // ALWAYS at vga_ball.sv:428
    if (vlTOPp->vga_ball__DOT__we_n) {
	__Vdlyvval__vga_ball__DOT__pn1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__din_n;
	__Vdlyvset__vga_ball__DOT__pn1__DOT__mem__v0 = 1U;
	__Vdlyvdim0__vga_ball__DOT__pn1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__wa_n;
    }
    // ALWAYS at vga_ball.sv:443
    if (vlTOPp->vga_ball__DOT__we_pg) {
	__Vdlyvval__vga_ball__DOT__pg1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__din_pg;
	__Vdlyvset__vga_ball__DOT__pg1__DOT__mem__v0 = 1U;
	__Vdlyvdim0__vga_ball__DOT__pg1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__wa_pg;
    }
    // ALWAYS at vga_ball.sv:398
    if (vlTOPp->vga_ball__DOT__we_a) {
	__Vdlyvval__vga_ball__DOT__sat1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__din_a;
	__Vdlyvset__vga_ball__DOT__sat1__DOT__mem__v0 = 1U;
	__Vdlyvdim0__vga_ball__DOT__sat1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__wa_a;
    }
    // ALWAYS at vga_ball.sv:413
    if (vlTOPp->vga_ball__DOT__we_g) {
	__Vdlyvval__vga_ball__DOT__sgt1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__din_g;
	__Vdlyvset__vga_ball__DOT__sgt1__DOT__mem__v0 = 1U;
	__Vdlyvdim0__vga_ball__DOT__sgt1__DOT__mem__v0 
	    = vlTOPp->vga_ball__DOT__wa_g;
    }
    // ALWAYS at vga_ball.sv:315
    __Vdly__vga_ball__DOT__pp0__DOT__state = vlTOPp->vga_ball__DOT__pp0__DOT__state_next;
    if (vlTOPp->reset) {
	__Vdly__vga_ball__DOT__pp0__DOT__state = 0U;
	__Vdly__vga_ball__DOT__ra_n = 0U;
	__Vdly__vga_ball__DOT__ra_pg = 0U;
    }
    if ((0U == vlTOPp->vga_ball__DOT__pp0__DOT__state)) {
	__Vdly__vga_ball__DOT__pp0__DOT__tile_total_counter = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__tile_pixel_counter = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[1U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[2U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[3U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[4U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[5U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[6U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[7U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[8U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[9U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xaU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xbU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xcU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xdU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xeU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xfU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x10U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x11U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x12U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x13U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x14U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x15U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x16U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x17U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x18U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x19U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1aU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1bU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1cU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1dU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1eU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1fU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x20U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x21U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x22U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x23U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x24U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x25U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x26U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x27U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x28U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x29U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2aU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2bU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2cU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2dU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2eU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2fU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x30U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x31U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x32U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x33U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x34U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x35U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x36U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x37U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x38U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x39U] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3aU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3bU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3cU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3dU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3eU] = 0U;
	vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3fU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[1U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[2U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[3U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[4U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[5U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[6U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[7U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[8U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[9U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xaU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xbU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xcU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xdU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xeU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xfU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x10U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x11U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x12U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x13U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x14U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x15U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x16U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x17U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x18U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x19U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1aU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1bU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1cU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1dU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1eU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1fU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x20U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x21U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x22U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x23U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x24U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x25U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x26U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x27U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x28U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x29U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2aU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2bU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2cU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2dU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2eU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2fU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x30U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x31U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x32U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x33U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x34U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x35U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x36U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x37U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x38U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x39U] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3aU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3bU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3cU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3dU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3eU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3fU] = 0U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_reg_shift = 0x800U;
	__Vdly__vga_ball__DOT__pp0__DOT__shift_pos = 0x800U;
    } else {
	if ((1U == vlTOPp->vga_ball__DOT__pp0__DOT__state)) {
	    __Vdly__vga_ball__DOT__ra_n = (0xfc0U & 
					   ((IData)(vlTOPp->vga_ball__DOT__vcount) 
					    << 3U));
	    __Vdly__vga_ball__DOT__pp0__DOT__pattern_row_offset 
		= (7U & (IData)(vlTOPp->vga_ball__DOT__vcount));
	} else {
	    if ((3U == vlTOPp->vga_ball__DOT__pp0__DOT__state)) {
		__Vdly__vga_ball__DOT__ra_pg = (0x7ffU 
						& ((0x7e0U 
						    & ((IData)(vlTOPp->vga_ball__DOT__dout_n) 
						       << 5U)) 
						   + 
						   ((IData)(vlTOPp->vga_ball__DOT__pp0__DOT__pattern_row_offset) 
						    << 2U)));
	    } else {
		if ((4U == vlTOPp->vga_ball__DOT__pp0__DOT__state)) {
		    __Vdly__vga_ball__DOT__ra_pg = 
			(0x7ffU & ((IData)(1U) + (IData)(vlTOPp->vga_ball__DOT__ra_pg)));
		} else {
		    if ((5U == vlTOPp->vga_ball__DOT__pp0__DOT__state)) {
			VL_EXTEND_WI(2048,8, __Vtemp1, (IData)(vlTOPp->vga_ball__DOT__dout_pg));
			VL_SHIFTL_WWI(2048,2048,12, __Vtemp2, __Vtemp1, 
				      (0xfffU & ((IData)(vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg_shift) 
						 - (IData)(8U))));
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0U] 
			    = (__Vtemp2[0U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[1U] 
			    = (__Vtemp2[1U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[1U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[2U] 
			    = (__Vtemp2[2U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[2U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[3U] 
			    = (__Vtemp2[3U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[3U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[4U] 
			    = (__Vtemp2[4U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[4U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[5U] 
			    = (__Vtemp2[5U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[5U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[6U] 
			    = (__Vtemp2[6U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[6U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[7U] 
			    = (__Vtemp2[7U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[7U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[8U] 
			    = (__Vtemp2[8U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[8U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[9U] 
			    = (__Vtemp2[9U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[9U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xaU] 
			    = (__Vtemp2[0xaU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xaU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xbU] 
			    = (__Vtemp2[0xbU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xbU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xcU] 
			    = (__Vtemp2[0xcU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xcU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xdU] 
			    = (__Vtemp2[0xdU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xdU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xeU] 
			    = (__Vtemp2[0xeU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xeU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xfU] 
			    = (__Vtemp2[0xfU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xfU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x10U] 
			    = (__Vtemp2[0x10U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x10U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x11U] 
			    = (__Vtemp2[0x11U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x11U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x12U] 
			    = (__Vtemp2[0x12U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x12U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x13U] 
			    = (__Vtemp2[0x13U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x13U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x14U] 
			    = (__Vtemp2[0x14U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x14U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x15U] 
			    = (__Vtemp2[0x15U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x15U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x16U] 
			    = (__Vtemp2[0x16U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x16U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x17U] 
			    = (__Vtemp2[0x17U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x17U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x18U] 
			    = (__Vtemp2[0x18U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x18U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x19U] 
			    = (__Vtemp2[0x19U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x19U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1aU] 
			    = (__Vtemp2[0x1aU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1aU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1bU] 
			    = (__Vtemp2[0x1bU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1bU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1cU] 
			    = (__Vtemp2[0x1cU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1cU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1dU] 
			    = (__Vtemp2[0x1dU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1dU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1eU] 
			    = (__Vtemp2[0x1eU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1eU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1fU] 
			    = (__Vtemp2[0x1fU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1fU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x20U] 
			    = (__Vtemp2[0x20U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x20U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x21U] 
			    = (__Vtemp2[0x21U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x21U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x22U] 
			    = (__Vtemp2[0x22U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x22U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x23U] 
			    = (__Vtemp2[0x23U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x23U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x24U] 
			    = (__Vtemp2[0x24U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x24U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x25U] 
			    = (__Vtemp2[0x25U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x25U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x26U] 
			    = (__Vtemp2[0x26U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x26U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x27U] 
			    = (__Vtemp2[0x27U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x27U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x28U] 
			    = (__Vtemp2[0x28U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x28U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x29U] 
			    = (__Vtemp2[0x29U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x29U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2aU] 
			    = (__Vtemp2[0x2aU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2aU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2bU] 
			    = (__Vtemp2[0x2bU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2bU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2cU] 
			    = (__Vtemp2[0x2cU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2cU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2dU] 
			    = (__Vtemp2[0x2dU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2dU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2eU] 
			    = (__Vtemp2[0x2eU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2eU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2fU] 
			    = (__Vtemp2[0x2fU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2fU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x30U] 
			    = (__Vtemp2[0x30U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x30U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x31U] 
			    = (__Vtemp2[0x31U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x31U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x32U] 
			    = (__Vtemp2[0x32U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x32U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x33U] 
			    = (__Vtemp2[0x33U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x33U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x34U] 
			    = (__Vtemp2[0x34U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x34U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x35U] 
			    = (__Vtemp2[0x35U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x35U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x36U] 
			    = (__Vtemp2[0x36U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x36U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x37U] 
			    = (__Vtemp2[0x37U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x37U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x38U] 
			    = (__Vtemp2[0x38U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x38U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x39U] 
			    = (__Vtemp2[0x39U] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x39U]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3aU] 
			    = (__Vtemp2[0x3aU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3aU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3bU] 
			    = (__Vtemp2[0x3bU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3bU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3cU] 
			    = (__Vtemp2[0x3cU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3cU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3dU] 
			    = (__Vtemp2[0x3dU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3dU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3eU] 
			    = (__Vtemp2[0x3eU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3eU]);
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3fU] 
			    = (__Vtemp2[0x3fU] | vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3fU]);
			__Vdly__vga_ball__DOT__ra_pg 
			    = (0x7ffU & ((IData)(1U) 
					 + (IData)(vlTOPp->vga_ball__DOT__ra_pg)));
			__Vdly__vga_ball__DOT__pp0__DOT__tile_pixel_counter 
			    = (0xffU & ((IData)(1U) 
					+ (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__tile_pixel_counter)));
			__Vdly__vga_ball__DOT__pp0__DOT__shift_reg_shift 
			    = (0xfffU & ((IData)(vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg_shift) 
					 - (IData)(8U)));
		    } else {
			if ((7U == vlTOPp->vga_ball__DOT__pp0__DOT__state)) {
			    __Vdly__vga_ball__DOT__ra_n 
				= (0xfffU & ((IData)(1U) 
					     + (IData)(vlTOPp->vga_ball__DOT__ra_n)));
			    __Vdly__vga_ball__DOT__pp0__DOT__tile_total_counter 
				= (0xffU & ((IData)(1U) 
					    + (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__tile_total_counter)));
			    __Vdly__vga_ball__DOT__pp0__DOT__tile_pixel_counter = 0U;
			} else {
			    if ((0xaU == vlTOPp->vga_ball__DOT__pp0__DOT__state)) {
				if (((IData)(vlTOPp->VGA_BLANK_n) 
				     & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
				    VL_SHIFTR_WWI(2048,2048,12, __Vtemp4, vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg, 
						  (0xfffU 
						   & ((IData)(vlTOPp->vga_ball__DOT__pp0__DOT__shift_pos) 
						      - (IData)(4U))));
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0U] 
					= __Vtemp4[0U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[1U] 
					= __Vtemp4[1U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[2U] 
					= __Vtemp4[2U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[3U] 
					= __Vtemp4[3U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[4U] 
					= __Vtemp4[4U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[5U] 
					= __Vtemp4[5U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[6U] 
					= __Vtemp4[6U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[7U] 
					= __Vtemp4[7U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[8U] 
					= __Vtemp4[8U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[9U] 
					= __Vtemp4[9U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xaU] 
					= __Vtemp4[0xaU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xbU] 
					= __Vtemp4[0xbU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xcU] 
					= __Vtemp4[0xcU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xdU] 
					= __Vtemp4[0xdU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xeU] 
					= __Vtemp4[0xeU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0xfU] 
					= __Vtemp4[0xfU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x10U] 
					= __Vtemp4[0x10U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x11U] 
					= __Vtemp4[0x11U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x12U] 
					= __Vtemp4[0x12U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x13U] 
					= __Vtemp4[0x13U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x14U] 
					= __Vtemp4[0x14U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x15U] 
					= __Vtemp4[0x15U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x16U] 
					= __Vtemp4[0x16U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x17U] 
					= __Vtemp4[0x17U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x18U] 
					= __Vtemp4[0x18U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x19U] 
					= __Vtemp4[0x19U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1aU] 
					= __Vtemp4[0x1aU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1bU] 
					= __Vtemp4[0x1bU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1cU] 
					= __Vtemp4[0x1cU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1dU] 
					= __Vtemp4[0x1dU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1eU] 
					= __Vtemp4[0x1eU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x1fU] 
					= __Vtemp4[0x1fU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x20U] 
					= __Vtemp4[0x20U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x21U] 
					= __Vtemp4[0x21U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x22U] 
					= __Vtemp4[0x22U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x23U] 
					= __Vtemp4[0x23U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x24U] 
					= __Vtemp4[0x24U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x25U] 
					= __Vtemp4[0x25U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x26U] 
					= __Vtemp4[0x26U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x27U] 
					= __Vtemp4[0x27U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x28U] 
					= __Vtemp4[0x28U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x29U] 
					= __Vtemp4[0x29U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2aU] 
					= __Vtemp4[0x2aU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2bU] 
					= __Vtemp4[0x2bU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2cU] 
					= __Vtemp4[0x2cU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2dU] 
					= __Vtemp4[0x2dU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2eU] 
					= __Vtemp4[0x2eU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x2fU] 
					= __Vtemp4[0x2fU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x30U] 
					= __Vtemp4[0x30U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x31U] 
					= __Vtemp4[0x31U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x32U] 
					= __Vtemp4[0x32U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x33U] 
					= __Vtemp4[0x33U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x34U] 
					= __Vtemp4[0x34U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x35U] 
					= __Vtemp4[0x35U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x36U] 
					= __Vtemp4[0x36U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x37U] 
					= __Vtemp4[0x37U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x38U] 
					= __Vtemp4[0x38U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x39U] 
					= __Vtemp4[0x39U];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3aU] 
					= __Vtemp4[0x3aU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3bU] 
					= __Vtemp4[0x3bU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3cU] 
					= __Vtemp4[0x3cU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3dU] 
					= __Vtemp4[0x3dU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3eU] 
					= __Vtemp4[0x3eU];
				    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0x3fU] 
					= __Vtemp4[0x3fU];
				    __Vdly__vga_ball__DOT__pp0__DOT__shift_pos 
					= (0xfffU & 
					   ((IData)(vlTOPp->vga_ball__DOT__pp0__DOT__shift_pos) 
					    - (IData)(4U)));
				}
			    }
			}
		    }
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:214
    __Vdly__vga_ball__DOT__sp0__DOT__state = vlTOPp->vga_ball__DOT__sp0__DOT__state_next;
    if (vlTOPp->reset) {
	__Vdly__vga_ball__DOT__sp0__DOT__state = 0U;
	__Vdly__vga_ball__DOT____Vcellout__sp0__ra_g = 0U;
	vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_a = 0U;
    }
    if (((((((((0U == vlTOPp->vga_ball__DOT__sp0__DOT__state) 
	       | (1U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
	      | (4U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
	     | (6U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
	    | (8U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
	   | (0xaU == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
	  | (0xdU == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
	 | (0xeU == vlTOPp->vga_ball__DOT__sp0__DOT__state))) {
	if ((0U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) {
	    vlTOPp->vga_ball__DOT__sp0__DOT__display_pixel = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp0__DOT__shift_reg = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp0__DOT__shift_reg_shift = 0x40U;
	    __Vdly__vga_ball__DOT__sp0__DOT__shift_pos = 0x40U;
	} else {
	    if ((1U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) {
		vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_a 
		    = vlTOPp->vga_ball__DOT__sprite_base_addr
		    [0U];
	    } else {
		if ((4U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) {
		    vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_a 
			= (0x1fU & ((IData)(1U) + vlTOPp->vga_ball__DOT__sprite_base_addr
				    [0U]));
		    __Vdly__vga_ball__DOT__sp0__DOT__sprite_offset 
			= (0x1ffU & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
				     - ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
					<< 1U)));
		} else {
		    if ((6U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) {
			vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_a 
			    = (0x1fU & ((IData)(2U) 
					+ vlTOPp->vga_ball__DOT__sprite_base_addr
					[0U]));
			__Vdly__vga_ball__DOT__sp0__DOT__down_counter 
			    = ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
			       << 1U);
		    } else {
			if ((8U == vlTOPp->vga_ball__DOT__sp0__DOT__state)) {
			    __Vdly__vga_ball__DOT____Vcellout__sp0__ra_g 
				= (0x7ffU & ((0x780U 
					      & ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
						 << 7U)) 
					     + ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__sprite_offset) 
						<< 3U)));
			} else {
			    if ((0xaU == vlTOPp->vga_ball__DOT__sp0__DOT__state)) {
				__Vdly__vga_ball__DOT__sp0__DOT__shift_reg 
				    = (((0x3fU >= (0xffU 
						   & ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift) 
						      - (IData)(8U))))
					 ? ((QData)((IData)(vlTOPp->vga_ball__DOT__dout_g)) 
					    << (0xffU 
						& ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift) 
						   - (IData)(8U))))
					 : VL_ULL(0)) 
				       | vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg);
				__Vdly__vga_ball__DOT____Vcellout__sp0__ra_g 
				    = (0x7ffU & ((IData)(1U) 
						 + (IData)(vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_g)));
				__Vdly__vga_ball__DOT__sp0__DOT__shift_reg_shift 
				    = (0xffU & ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift) 
						- (IData)(8U)));
			    } else {
				if ((0xdU == vlTOPp->vga_ball__DOT__sp0__DOT__state)) {
				    if ((((0U < (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__down_counter)) 
					  & (IData)(vlTOPp->VGA_BLANK_n)) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					__Vdly__vga_ball__DOT__sp0__DOT__down_counter 
					    = (0x1ffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__down_counter) 
						  - (IData)(1U)));
				    }
				} else {
				    if (((IData)(vlTOPp->VGA_BLANK_n) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					vlTOPp->vga_ball__DOT__sp0__DOT__display_pixel 
					    = ((0x3fU 
						>= 
						(0xffU 
						 & ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos) 
						    - (IData)(4U))))
					        ? (vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg 
						   >> 
						   (0xffU 
						    & ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos) 
						       - (IData)(4U))))
					        : VL_ULL(0));
					__Vdly__vga_ball__DOT__sp0__DOT__shift_pos 
					    = (0xffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos) 
						  - (IData)(4U)));
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:214
    __Vdly__vga_ball__DOT__sp1__DOT__state = vlTOPp->vga_ball__DOT__sp1__DOT__state_next;
    if (vlTOPp->reset) {
	__Vdly__vga_ball__DOT__sp1__DOT__state = 0U;
	__Vdly__vga_ball__DOT____Vcellout__sp1__ra_g = 0U;
	vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_a = 0U;
    }
    if (((((((((0U == vlTOPp->vga_ball__DOT__sp1__DOT__state) 
	       | (1U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
	      | (4U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
	     | (6U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
	    | (8U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
	   | (0xaU == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
	  | (0xdU == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
	 | (0xeU == vlTOPp->vga_ball__DOT__sp1__DOT__state))) {
	if ((0U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) {
	    vlTOPp->vga_ball__DOT__sp1__DOT__display_pixel = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp1__DOT__shift_reg = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp1__DOT__shift_reg_shift = 0x40U;
	    __Vdly__vga_ball__DOT__sp1__DOT__shift_pos = 0x40U;
	} else {
	    if ((1U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) {
		vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_a 
		    = vlTOPp->vga_ball__DOT__sprite_base_addr
		    [1U];
	    } else {
		if ((4U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) {
		    vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_a 
			= (0x1fU & ((IData)(1U) + vlTOPp->vga_ball__DOT__sprite_base_addr
				    [1U]));
		    __Vdly__vga_ball__DOT__sp1__DOT__sprite_offset 
			= (0x1ffU & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
				     - ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
					<< 1U)));
		} else {
		    if ((6U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) {
			vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_a 
			    = (0x1fU & ((IData)(2U) 
					+ vlTOPp->vga_ball__DOT__sprite_base_addr
					[1U]));
			__Vdly__vga_ball__DOT__sp1__DOT__down_counter 
			    = ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
			       << 1U);
		    } else {
			if ((8U == vlTOPp->vga_ball__DOT__sp1__DOT__state)) {
			    __Vdly__vga_ball__DOT____Vcellout__sp1__ra_g 
				= (0x7ffU & ((0x780U 
					      & ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
						 << 7U)) 
					     + ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__sprite_offset) 
						<< 3U)));
			} else {
			    if ((0xaU == vlTOPp->vga_ball__DOT__sp1__DOT__state)) {
				__Vdly__vga_ball__DOT__sp1__DOT__shift_reg 
				    = (((0x3fU >= (0xffU 
						   & ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift) 
						      - (IData)(8U))))
					 ? ((QData)((IData)(vlTOPp->vga_ball__DOT__dout_g)) 
					    << (0xffU 
						& ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift) 
						   - (IData)(8U))))
					 : VL_ULL(0)) 
				       | vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg);
				__Vdly__vga_ball__DOT____Vcellout__sp1__ra_g 
				    = (0x7ffU & ((IData)(1U) 
						 + (IData)(vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_g)));
				__Vdly__vga_ball__DOT__sp1__DOT__shift_reg_shift 
				    = (0xffU & ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift) 
						- (IData)(8U)));
			    } else {
				if ((0xdU == vlTOPp->vga_ball__DOT__sp1__DOT__state)) {
				    if ((((0U < (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__down_counter)) 
					  & (IData)(vlTOPp->VGA_BLANK_n)) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					__Vdly__vga_ball__DOT__sp1__DOT__down_counter 
					    = (0x1ffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__down_counter) 
						  - (IData)(1U)));
				    }
				} else {
				    if (((IData)(vlTOPp->VGA_BLANK_n) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					vlTOPp->vga_ball__DOT__sp1__DOT__display_pixel 
					    = ((0x3fU 
						>= 
						(0xffU 
						 & ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos) 
						    - (IData)(4U))))
					        ? (vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg 
						   >> 
						   (0xffU 
						    & ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos) 
						       - (IData)(4U))))
					        : VL_ULL(0));
					__Vdly__vga_ball__DOT__sp1__DOT__shift_pos 
					    = (0xffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos) 
						  - (IData)(4U)));
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:214
    __Vdly__vga_ball__DOT__sp2__DOT__state = vlTOPp->vga_ball__DOT__sp2__DOT__state_next;
    if (vlTOPp->reset) {
	__Vdly__vga_ball__DOT__sp2__DOT__state = 0U;
	__Vdly__vga_ball__DOT____Vcellout__sp2__ra_g = 0U;
	vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_a = 0U;
    }
    if (((((((((0U == vlTOPp->vga_ball__DOT__sp2__DOT__state) 
	       | (1U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
	      | (4U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
	     | (6U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
	    | (8U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
	   | (0xaU == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
	  | (0xdU == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
	 | (0xeU == vlTOPp->vga_ball__DOT__sp2__DOT__state))) {
	if ((0U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) {
	    vlTOPp->vga_ball__DOT__sp2__DOT__display_pixel = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp2__DOT__shift_reg = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp2__DOT__shift_reg_shift = 0x40U;
	    __Vdly__vga_ball__DOT__sp2__DOT__shift_pos = 0x40U;
	} else {
	    if ((1U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) {
		vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_a 
		    = vlTOPp->vga_ball__DOT__sprite_base_addr
		    [2U];
	    } else {
		if ((4U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) {
		    vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_a 
			= (0x1fU & ((IData)(1U) + vlTOPp->vga_ball__DOT__sprite_base_addr
				    [2U]));
		    __Vdly__vga_ball__DOT__sp2__DOT__sprite_offset 
			= (0x1ffU & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
				     - ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
					<< 1U)));
		} else {
		    if ((6U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) {
			vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_a 
			    = (0x1fU & ((IData)(2U) 
					+ vlTOPp->vga_ball__DOT__sprite_base_addr
					[2U]));
			__Vdly__vga_ball__DOT__sp2__DOT__down_counter 
			    = ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
			       << 1U);
		    } else {
			if ((8U == vlTOPp->vga_ball__DOT__sp2__DOT__state)) {
			    __Vdly__vga_ball__DOT____Vcellout__sp2__ra_g 
				= (0x7ffU & ((0x780U 
					      & ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
						 << 7U)) 
					     + ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__sprite_offset) 
						<< 3U)));
			} else {
			    if ((0xaU == vlTOPp->vga_ball__DOT__sp2__DOT__state)) {
				__Vdly__vga_ball__DOT__sp2__DOT__shift_reg 
				    = (((0x3fU >= (0xffU 
						   & ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift) 
						      - (IData)(8U))))
					 ? ((QData)((IData)(vlTOPp->vga_ball__DOT__dout_g)) 
					    << (0xffU 
						& ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift) 
						   - (IData)(8U))))
					 : VL_ULL(0)) 
				       | vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg);
				__Vdly__vga_ball__DOT____Vcellout__sp2__ra_g 
				    = (0x7ffU & ((IData)(1U) 
						 + (IData)(vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_g)));
				__Vdly__vga_ball__DOT__sp2__DOT__shift_reg_shift 
				    = (0xffU & ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift) 
						- (IData)(8U)));
			    } else {
				if ((0xdU == vlTOPp->vga_ball__DOT__sp2__DOT__state)) {
				    if ((((0U < (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__down_counter)) 
					  & (IData)(vlTOPp->VGA_BLANK_n)) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					__Vdly__vga_ball__DOT__sp2__DOT__down_counter 
					    = (0x1ffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__down_counter) 
						  - (IData)(1U)));
				    }
				} else {
				    if (((IData)(vlTOPp->VGA_BLANK_n) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					vlTOPp->vga_ball__DOT__sp2__DOT__display_pixel 
					    = ((0x3fU 
						>= 
						(0xffU 
						 & ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos) 
						    - (IData)(4U))))
					        ? (vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg 
						   >> 
						   (0xffU 
						    & ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos) 
						       - (IData)(4U))))
					        : VL_ULL(0));
					__Vdly__vga_ball__DOT__sp2__DOT__shift_pos 
					    = (0xffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos) 
						  - (IData)(4U)));
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:214
    __Vdly__vga_ball__DOT__sp3__DOT__state = vlTOPp->vga_ball__DOT__sp3__DOT__state_next;
    if (vlTOPp->reset) {
	__Vdly__vga_ball__DOT__sp3__DOT__state = 0U;
	__Vdly__vga_ball__DOT____Vcellout__sp3__ra_g = 0U;
	vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_a = 0U;
    }
    if (((((((((0U == vlTOPp->vga_ball__DOT__sp3__DOT__state) 
	       | (1U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
	      | (4U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
	     | (6U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
	    | (8U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
	   | (0xaU == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
	  | (0xdU == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
	 | (0xeU == vlTOPp->vga_ball__DOT__sp3__DOT__state))) {
	if ((0U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) {
	    vlTOPp->vga_ball__DOT__sp3__DOT__display_pixel = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp3__DOT__shift_reg = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp3__DOT__shift_reg_shift = 0x40U;
	    __Vdly__vga_ball__DOT__sp3__DOT__shift_pos = 0x40U;
	} else {
	    if ((1U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) {
		vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_a 
		    = vlTOPp->vga_ball__DOT__sprite_base_addr
		    [3U];
	    } else {
		if ((4U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) {
		    vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_a 
			= (0x1fU & ((IData)(1U) + vlTOPp->vga_ball__DOT__sprite_base_addr
				    [3U]));
		    __Vdly__vga_ball__DOT__sp3__DOT__sprite_offset 
			= (0x1ffU & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
				     - ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
					<< 1U)));
		} else {
		    if ((6U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) {
			vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_a 
			    = (0x1fU & ((IData)(2U) 
					+ vlTOPp->vga_ball__DOT__sprite_base_addr
					[3U]));
			__Vdly__vga_ball__DOT__sp3__DOT__down_counter 
			    = ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
			       << 1U);
		    } else {
			if ((8U == vlTOPp->vga_ball__DOT__sp3__DOT__state)) {
			    __Vdly__vga_ball__DOT____Vcellout__sp3__ra_g 
				= (0x7ffU & ((0x780U 
					      & ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
						 << 7U)) 
					     + ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__sprite_offset) 
						<< 3U)));
			} else {
			    if ((0xaU == vlTOPp->vga_ball__DOT__sp3__DOT__state)) {
				__Vdly__vga_ball__DOT__sp3__DOT__shift_reg 
				    = (((0x3fU >= (0xffU 
						   & ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift) 
						      - (IData)(8U))))
					 ? ((QData)((IData)(vlTOPp->vga_ball__DOT__dout_g)) 
					    << (0xffU 
						& ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift) 
						   - (IData)(8U))))
					 : VL_ULL(0)) 
				       | vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg);
				__Vdly__vga_ball__DOT____Vcellout__sp3__ra_g 
				    = (0x7ffU & ((IData)(1U) 
						 + (IData)(vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_g)));
				__Vdly__vga_ball__DOT__sp3__DOT__shift_reg_shift 
				    = (0xffU & ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift) 
						- (IData)(8U)));
			    } else {
				if ((0xdU == vlTOPp->vga_ball__DOT__sp3__DOT__state)) {
				    if ((((0U < (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__down_counter)) 
					  & (IData)(vlTOPp->VGA_BLANK_n)) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					__Vdly__vga_ball__DOT__sp3__DOT__down_counter 
					    = (0x1ffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__down_counter) 
						  - (IData)(1U)));
				    }
				} else {
				    if (((IData)(vlTOPp->VGA_BLANK_n) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					vlTOPp->vga_ball__DOT__sp3__DOT__display_pixel 
					    = ((0x3fU 
						>= 
						(0xffU 
						 & ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos) 
						    - (IData)(4U))))
					        ? (vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg 
						   >> 
						   (0xffU 
						    & ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos) 
						       - (IData)(4U))))
					        : VL_ULL(0));
					__Vdly__vga_ball__DOT__sp3__DOT__shift_pos 
					    = (0xffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos) 
						  - (IData)(4U)));
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:214
    __Vdly__vga_ball__DOT__sp4__DOT__state = vlTOPp->vga_ball__DOT__sp4__DOT__state_next;
    if (vlTOPp->reset) {
	__Vdly__vga_ball__DOT__sp4__DOT__state = 0U;
	__Vdly__vga_ball__DOT____Vcellout__sp4__ra_g = 0U;
	vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_a = 0U;
    }
    if (((((((((0U == vlTOPp->vga_ball__DOT__sp4__DOT__state) 
	       | (1U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
	      | (4U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
	     | (6U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
	    | (8U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
	   | (0xaU == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
	  | (0xdU == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
	 | (0xeU == vlTOPp->vga_ball__DOT__sp4__DOT__state))) {
	if ((0U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) {
	    vlTOPp->vga_ball__DOT__sp4__DOT__display_pixel = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp4__DOT__shift_reg = VL_ULL(0);
	    __Vdly__vga_ball__DOT__sp4__DOT__shift_reg_shift = 0x40U;
	    __Vdly__vga_ball__DOT__sp4__DOT__shift_pos = 0x40U;
	} else {
	    if ((1U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) {
		vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_a 
		    = vlTOPp->vga_ball__DOT__sprite_base_addr
		    [4U];
	    } else {
		if ((4U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) {
		    vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_a 
			= (0x1fU & ((IData)(1U) + vlTOPp->vga_ball__DOT__sprite_base_addr
				    [4U]));
		    __Vdly__vga_ball__DOT__sp4__DOT__sprite_offset 
			= (0x1ffU & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
				     - ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
					<< 1U)));
		} else {
		    if ((6U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) {
			vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_a 
			    = (0x1fU & ((IData)(2U) 
					+ vlTOPp->vga_ball__DOT__sprite_base_addr
					[4U]));
			__Vdly__vga_ball__DOT__sp4__DOT__down_counter 
			    = ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
			       << 1U);
		    } else {
			if ((8U == vlTOPp->vga_ball__DOT__sp4__DOT__state)) {
			    __Vdly__vga_ball__DOT____Vcellout__sp4__ra_g 
				= (0x7ffU & ((0x780U 
					      & ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
						 << 7U)) 
					     + ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__sprite_offset) 
						<< 3U)));
			} else {
			    if ((0xaU == vlTOPp->vga_ball__DOT__sp4__DOT__state)) {
				__Vdly__vga_ball__DOT__sp4__DOT__shift_reg 
				    = (((0x3fU >= (0xffU 
						   & ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift) 
						      - (IData)(8U))))
					 ? ((QData)((IData)(vlTOPp->vga_ball__DOT__dout_g)) 
					    << (0xffU 
						& ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift) 
						   - (IData)(8U))))
					 : VL_ULL(0)) 
				       | vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg);
				__Vdly__vga_ball__DOT____Vcellout__sp4__ra_g 
				    = (0x7ffU & ((IData)(1U) 
						 + (IData)(vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_g)));
				__Vdly__vga_ball__DOT__sp4__DOT__shift_reg_shift 
				    = (0xffU & ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift) 
						- (IData)(8U)));
			    } else {
				if ((0xdU == vlTOPp->vga_ball__DOT__sp4__DOT__state)) {
				    if ((((0U < (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__down_counter)) 
					  & (IData)(vlTOPp->VGA_BLANK_n)) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					__Vdly__vga_ball__DOT__sp4__DOT__down_counter 
					    = (0x1ffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__down_counter) 
						  - (IData)(1U)));
				    }
				} else {
				    if (((IData)(vlTOPp->VGA_BLANK_n) 
					 & (~ (IData)(vlTOPp->vga_ball__DOT__hcount)))) {
					vlTOPp->vga_ball__DOT__sp4__DOT__display_pixel 
					    = ((0x3fU 
						>= 
						(0xffU 
						 & ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos) 
						    - (IData)(4U))))
					        ? (vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg 
						   >> 
						   (0xffU 
						    & ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos) 
						       - (IData)(4U))))
					        : VL_ULL(0));
					__Vdly__vga_ball__DOT__sp4__DOT__shift_pos 
					    = (0xffU 
					       & ((IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos) 
						  - (IData)(4U)));
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    vlTOPp->vga_ball__DOT__pp0__DOT__pattern_row_offset 
	= __Vdly__vga_ball__DOT__pp0__DOT__pattern_row_offset;
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg_shift 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg_shift;
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[1U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[1U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[2U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[2U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[3U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[3U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[4U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[4U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[5U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[5U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[6U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[6U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[7U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[7U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[8U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[8U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[9U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[9U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xaU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xaU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xbU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xbU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xcU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xcU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xdU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xdU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xeU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xeU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0xfU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0xfU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x10U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x10U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x11U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x11U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x12U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x12U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x13U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x13U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x14U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x14U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x15U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x15U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x16U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x16U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x17U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x17U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x18U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x18U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x19U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x19U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1aU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1aU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1bU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1bU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1cU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1cU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1dU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1dU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1eU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1eU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x1fU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x1fU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x20U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x20U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x21U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x21U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x22U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x22U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x23U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x23U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x24U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x24U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x25U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x25U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x26U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x26U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x27U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x27U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x28U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x28U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x29U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x29U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2aU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2aU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2bU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2bU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2cU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2cU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2dU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2dU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2eU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2eU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x2fU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x2fU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x30U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x30U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x31U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x31U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x32U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x32U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x33U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x33U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x34U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x34U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x35U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x35U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x36U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x36U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x37U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x37U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x38U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x38U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x39U] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x39U];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3aU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3aU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3bU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3bU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3cU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3cU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3dU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3dU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3eU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3eU];
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_reg[0x3fU] 
	= __Vdly__vga_ball__DOT__pp0__DOT__shift_reg[0x3fU];
    vlTOPp->vga_ball__DOT__pp0__DOT__state = __Vdly__vga_ball__DOT__pp0__DOT__state;
    vlTOPp->vga_ball__DOT__pp0__DOT__tile_pixel_counter 
	= __Vdly__vga_ball__DOT__pp0__DOT__tile_pixel_counter;
    vlTOPp->vga_ball__DOT__pp0__DOT__tile_total_counter 
	= __Vdly__vga_ball__DOT__pp0__DOT__tile_total_counter;
    vlTOPp->vga_ball__DOT__pp0__DOT__shift_pos = __Vdly__vga_ball__DOT__pp0__DOT__shift_pos;
    vlTOPp->vga_ball__DOT__sp0__DOT__sprite_offset 
	= __Vdly__vga_ball__DOT__sp0__DOT__sprite_offset;
    vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg = __Vdly__vga_ball__DOT__sp0__DOT__shift_reg;
    vlTOPp->vga_ball__DOT__sp0__DOT__state = __Vdly__vga_ball__DOT__sp0__DOT__state;
    vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift 
	= __Vdly__vga_ball__DOT__sp0__DOT__shift_reg_shift;
    vlTOPp->vga_ball__DOT__sp0__DOT__down_counter = __Vdly__vga_ball__DOT__sp0__DOT__down_counter;
    vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos = __Vdly__vga_ball__DOT__sp0__DOT__shift_pos;
    vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_g = __Vdly__vga_ball__DOT____Vcellout__sp0__ra_g;
    vlTOPp->vga_ball__DOT__sp1__DOT__sprite_offset 
	= __Vdly__vga_ball__DOT__sp1__DOT__sprite_offset;
    vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg = __Vdly__vga_ball__DOT__sp1__DOT__shift_reg;
    vlTOPp->vga_ball__DOT__sp1__DOT__state = __Vdly__vga_ball__DOT__sp1__DOT__state;
    vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift 
	= __Vdly__vga_ball__DOT__sp1__DOT__shift_reg_shift;
    vlTOPp->vga_ball__DOT__sp1__DOT__down_counter = __Vdly__vga_ball__DOT__sp1__DOT__down_counter;
    vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos = __Vdly__vga_ball__DOT__sp1__DOT__shift_pos;
    vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_g = __Vdly__vga_ball__DOT____Vcellout__sp1__ra_g;
    vlTOPp->vga_ball__DOT__sp2__DOT__sprite_offset 
	= __Vdly__vga_ball__DOT__sp2__DOT__sprite_offset;
    vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg = __Vdly__vga_ball__DOT__sp2__DOT__shift_reg;
    vlTOPp->vga_ball__DOT__sp2__DOT__state = __Vdly__vga_ball__DOT__sp2__DOT__state;
    vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift 
	= __Vdly__vga_ball__DOT__sp2__DOT__shift_reg_shift;
    vlTOPp->vga_ball__DOT__sp2__DOT__down_counter = __Vdly__vga_ball__DOT__sp2__DOT__down_counter;
    vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos = __Vdly__vga_ball__DOT__sp2__DOT__shift_pos;
    vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_g = __Vdly__vga_ball__DOT____Vcellout__sp2__ra_g;
    vlTOPp->vga_ball__DOT__sp3__DOT__sprite_offset 
	= __Vdly__vga_ball__DOT__sp3__DOT__sprite_offset;
    vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg = __Vdly__vga_ball__DOT__sp3__DOT__shift_reg;
    vlTOPp->vga_ball__DOT__sp3__DOT__state = __Vdly__vga_ball__DOT__sp3__DOT__state;
    vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift 
	= __Vdly__vga_ball__DOT__sp3__DOT__shift_reg_shift;
    vlTOPp->vga_ball__DOT__sp3__DOT__down_counter = __Vdly__vga_ball__DOT__sp3__DOT__down_counter;
    vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos = __Vdly__vga_ball__DOT__sp3__DOT__shift_pos;
    vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_g = __Vdly__vga_ball__DOT____Vcellout__sp3__ra_g;
    vlTOPp->vga_ball__DOT__sp4__DOT__sprite_offset 
	= __Vdly__vga_ball__DOT__sp4__DOT__sprite_offset;
    vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg = __Vdly__vga_ball__DOT__sp4__DOT__shift_reg;
    vlTOPp->vga_ball__DOT__sp4__DOT__state = __Vdly__vga_ball__DOT__sp4__DOT__state;
    vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift 
	= __Vdly__vga_ball__DOT__sp4__DOT__shift_reg_shift;
    vlTOPp->vga_ball__DOT__sp4__DOT__down_counter = __Vdly__vga_ball__DOT__sp4__DOT__down_counter;
    vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos = __Vdly__vga_ball__DOT__sp4__DOT__shift_pos;
    vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_g = __Vdly__vga_ball__DOT____Vcellout__sp4__ra_g;
    // ALWAYS at vga_ball.sv:100
    if (vlTOPp->reset) {
	vlTOPp->vga_ball__DOT__background_r = 0U;
	vlTOPp->vga_ball__DOT__background_g = 0U;
	vlTOPp->vga_ball__DOT__background_b = 0x20U;
    } else {
	if (((IData)(vlTOPp->chipselect) & (IData)(vlTOPp->write))) {
	    if ((2U & vlTOPp->writedata)) {
		if ((1U & vlTOPp->writedata)) {
		    vlTOPp->vga_ball__DOT__we_n = 0U;
		    vlTOPp->vga_ball__DOT__we_pg = 0U;
		    vlTOPp->vga_ball__DOT__we_a = 0U;
		    vlTOPp->vga_ball__DOT__we_g = 1U;
		    vlTOPp->vga_ball__DOT__din_g = 
			(0xffU & (vlTOPp->writedata 
				  >> 0x18U));
		    vlTOPp->vga_ball__DOT__wa_g = (0x7ffU 
						   & (vlTOPp->writedata 
						      >> 2U));
		} else {
		    vlTOPp->vga_ball__DOT__we_n = 0U;
		    vlTOPp->vga_ball__DOT__we_pg = 0U;
		    vlTOPp->vga_ball__DOT__we_a = 1U;
		    vlTOPp->vga_ball__DOT__we_g = 0U;
		    vlTOPp->vga_ball__DOT__din_a = 
			(0xffU & (vlTOPp->writedata 
				  >> 0x18U));
		    vlTOPp->vga_ball__DOT__wa_a = (0x1fU 
						   & (vlTOPp->writedata 
						      >> 2U));
		}
	    } else {
		if ((1U & vlTOPp->writedata)) {
		    vlTOPp->vga_ball__DOT__we_n = 0U;
		    vlTOPp->vga_ball__DOT__we_pg = 1U;
		    vlTOPp->vga_ball__DOT__we_a = 0U;
		    vlTOPp->vga_ball__DOT__we_g = 0U;
		    vlTOPp->vga_ball__DOT__din_pg = 
			(0xffU & (vlTOPp->writedata 
				  >> 0x18U));
		    vlTOPp->vga_ball__DOT__wa_pg = 
			(0x7ffU & (vlTOPp->writedata 
				   >> 2U));
		} else {
		    vlTOPp->vga_ball__DOT__we_n = 1U;
		    vlTOPp->vga_ball__DOT__we_pg = 0U;
		    vlTOPp->vga_ball__DOT__we_a = 0U;
		    vlTOPp->vga_ball__DOT__we_g = 0U;
		    vlTOPp->vga_ball__DOT__din_n = 
			(0xffU & (vlTOPp->writedata 
				  >> 0x18U));
		    vlTOPp->vga_ball__DOT__wa_n = (0xfffU 
						   & (vlTOPp->writedata 
						      >> 2U));
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:428
    vlTOPp->vga_ball__DOT__dout_n = vlTOPp->vga_ball__DOT__pn1__DOT__mem
	[vlTOPp->vga_ball__DOT__ra_n];
    // ALWAYS at vga_ball.sv:443
    vlTOPp->vga_ball__DOT__dout_pg = vlTOPp->vga_ball__DOT__pg1__DOT__mem
	[vlTOPp->vga_ball__DOT__ra_pg];
    vlTOPp->vga_ball__DOT__out_pixel[5U] = (0xfU & 
					    vlTOPp->vga_ball__DOT__pp0__DOT__display_pixel[0U]);
    vlTOPp->vga_ball__DOT__sprite_ra_g[0U] = vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[0U] = vlTOPp->vga_ball__DOT____Vcellout__sp0__ra_a;
    vlTOPp->vga_ball__DOT__out_pixel[0U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__sprite_ra_g[1U] = vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[1U] = vlTOPp->vga_ball__DOT____Vcellout__sp1__ra_a;
    vlTOPp->vga_ball__DOT__out_pixel[1U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__sprite_ra_g[2U] = vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[2U] = vlTOPp->vga_ball__DOT____Vcellout__sp2__ra_a;
    vlTOPp->vga_ball__DOT__out_pixel[2U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__sprite_ra_g[3U] = vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[3U] = vlTOPp->vga_ball__DOT____Vcellout__sp3__ra_a;
    vlTOPp->vga_ball__DOT__out_pixel[3U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__display_pixel));
    // ALWAYS at vga_ball.sv:413
    vlTOPp->vga_ball__DOT__dout_g = vlTOPp->vga_ball__DOT__sgt1__DOT__mem
	[vlTOPp->vga_ball__DOT__ra_g];
    vlTOPp->vga_ball__DOT__sprite_ra_g[4U] = vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_g;
    vlTOPp->vga_ball__DOT__sprite_ra_a[4U] = vlTOPp->vga_ball__DOT____Vcellout__sp4__ra_a;
    // ALWAYS at vga_ball.sv:398
    vlTOPp->vga_ball__DOT__dout_a = vlTOPp->vga_ball__DOT__sat1__DOT__mem
	[vlTOPp->vga_ball__DOT__ra_a];
    vlTOPp->vga_ball__DOT__out_pixel[4U] = (0xfU & (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__display_pixel));
    vlTOPp->vga_ball__DOT__ra_n = __Vdly__vga_ball__DOT__ra_n;
    // ALWAYSPOST at vga_ball.sv:428
    if (__Vdlyvset__vga_ball__DOT__pn1__DOT__mem__v0) {
	vlTOPp->vga_ball__DOT__pn1__DOT__mem[__Vdlyvdim0__vga_ball__DOT__pn1__DOT__mem__v0] 
	    = __Vdlyvval__vga_ball__DOT__pn1__DOT__mem__v0;
    }
    vlTOPp->vga_ball__DOT__ra_pg = __Vdly__vga_ball__DOT__ra_pg;
    // ALWAYSPOST at vga_ball.sv:443
    if (__Vdlyvset__vga_ball__DOT__pg1__DOT__mem__v0) {
	vlTOPp->vga_ball__DOT__pg1__DOT__mem[__Vdlyvdim0__vga_ball__DOT__pg1__DOT__mem__v0] 
	    = __Vdlyvval__vga_ball__DOT__pg1__DOT__mem__v0;
    }
    // ALWAYSPOST at vga_ball.sv:413
    if (__Vdlyvset__vga_ball__DOT__sgt1__DOT__mem__v0) {
	vlTOPp->vga_ball__DOT__sgt1__DOT__mem[__Vdlyvdim0__vga_ball__DOT__sgt1__DOT__mem__v0] 
	    = __Vdlyvval__vga_ball__DOT__sgt1__DOT__mem__v0;
    }
    // ALWAYSPOST at vga_ball.sv:398
    if (__Vdlyvset__vga_ball__DOT__sat1__DOT__mem__v0) {
	vlTOPp->vga_ball__DOT__sat1__DOT__mem[__Vdlyvdim0__vga_ball__DOT__sat1__DOT__mem__v0] 
	    = __Vdlyvval__vga_ball__DOT__sat1__DOT__mem__v0;
    }
    // ALWAYS at vga_ball.sv:151
    vlTOPp->vga_ball__DOT__final_out_pixel = ((0U != 
					       vlTOPp->vga_ball__DOT__out_pixel
					       [0U])
					       ? vlTOPp->vga_ball__DOT__out_pixel
					      [0U] : 
					      ((0U 
						!= 
						vlTOPp->vga_ball__DOT__out_pixel
						[1U])
					        ? vlTOPp->vga_ball__DOT__out_pixel
					       [1U]
					        : (
						   (0U 
						    != 
						    vlTOPp->vga_ball__DOT__out_pixel
						    [2U])
						    ? 
						   vlTOPp->vga_ball__DOT__out_pixel
						   [2U]
						    : 
						   ((0U 
						     != 
						     vlTOPp->vga_ball__DOT__out_pixel
						     [3U])
						     ? 
						    vlTOPp->vga_ball__DOT__out_pixel
						    [3U]
						     : 
						    ((0U 
						      != 
						      vlTOPp->vga_ball__DOT__out_pixel
						      [4U])
						      ? 
						     vlTOPp->vga_ball__DOT__out_pixel
						     [4U]
						      : 
						     ((0U 
						       != 
						       vlTOPp->vga_ball__DOT__out_pixel
						       [5U])
						       ? 
						      vlTOPp->vga_ball__DOT__out_pixel
						      [5U]
						       : 0U))))));
    // ALWAYS at vga_ball.sv:450
    vlTOPp->__Vtableidx1 = vlTOPp->vga_ball__DOT__final_out_pixel;
    vlTOPp->vga_ball__DOT__rgb_val = vlTOPp->__Vtable1_vga_ball__DOT__rgb_val
	[vlTOPp->__Vtableidx1];
}

VL_INLINE_OPT void Vvga_ball::_sequent__TOP__4(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_sequent__TOP__4\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    VL_SIG16(__Vdly__vga_ball__DOT__hcount,10,0);
    VL_SIG16(__Vdly__vga_ball__DOT__vcount,9,0);
    // Body
    __Vdly__vga_ball__DOT__hcount = vlTOPp->vga_ball__DOT__hcount;
    __Vdly__vga_ball__DOT__vcount = vlTOPp->vga_ball__DOT__vcount;
    // ALWAYS at vga_ball.sv:504
    __Vdly__vga_ball__DOT__hcount = (0x7ffU & ((IData)(vlTOPp->reset)
					        ? 0U
					        : ((IData)(vlTOPp->vga_ball__DOT__counters__DOT__endOfLine)
						    ? 0U
						    : 
						   ((IData)(1U) 
						    + (IData)(vlTOPp->vga_ball__DOT__hcount)))));
    // ALWAYS at vga_ball.sv:513
    if (vlTOPp->reset) {
	__Vdly__vga_ball__DOT__vcount = 0U;
    } else {
	if ((0x63fU == (IData)(vlTOPp->vga_ball__DOT__hcount))) {
	    __Vdly__vga_ball__DOT__vcount = (0x3ffU 
					     & ((IData)(vlTOPp->vga_ball__DOT__counters__DOT__endOfField)
						 ? 0U
						 : 
						((IData)(1U) 
						 + (IData)(vlTOPp->vga_ball__DOT__vcount))));
	}
    }
    vlTOPp->vga_ball__DOT__vcount = __Vdly__vga_ball__DOT__vcount;
    vlTOPp->vga_ball__DOT__hcount = __Vdly__vga_ball__DOT__hcount;
    vlTOPp->vga_ball__DOT__counters__DOT__endOfField 
	= (0x20cU == (IData)(vlTOPp->vga_ball__DOT__vcount));
    vlTOPp->VGA_VS = (0xf5U != (0x1ffU & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
					  >> 1U)));
    vlTOPp->vga_ball__DOT__counters__DOT__endOfLine 
	= (0x63fU == (IData)(vlTOPp->vga_ball__DOT__hcount));
    vlTOPp->VGA_HS = (1U & (~ ((5U == (7U & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
					     >> 8U))) 
			       & (7U != (7U & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
					       >> 5U))))));
    vlTOPp->VGA_CLK = (1U & (IData)(vlTOPp->vga_ball__DOT__hcount));
    // ALWAYS at vga_ball.sv:368
    vlTOPp->vga_ball__DOT__pp0__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__pp0__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						     | (7U 
							== vlTOPp->vga_ball__DOT__pp0__DOT__state)) 
						    | (8U 
						       == vlTOPp->vga_ball__DOT__pp0__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						     ? 
						    ((0x520U 
						      == (IData)(vlTOPp->vga_ball__DOT__hcount))
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__pp0__DOT__state)
						        ? 4U
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__pp0__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__pp0__DOT__state)
							  ? 
							 ((3U 
							   == (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__tile_pixel_counter))
							   ? 7U
							   : 5U)
							  : 
							 ((7U 
							   == vlTOPp->vga_ball__DOT__pp0__DOT__state)
							   ? 8U
							   : 
							  ((0x40U 
							    == (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__tile_total_counter))
							    ? 9U
							    : 3U))))))))
						    : 
						   ((9U 
						     == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						     ? 
						    ((0x40U 
						      == (IData)(vlTOPp->vga_ball__DOT__hcount))
						      ? 0xaU
						      : 9U)
						     : 
						    ((0xaU 
						      == vlTOPp->vga_ball__DOT__pp0__DOT__state)
						      ? 
						     ((0U 
						       == (IData)(vlTOPp->vga_ball__DOT__pp0__DOT__shift_pos))
						       ? 0U
						       : 0xaU)
						      : 0U)));
    vlTOPp->VGA_BLANK_n = (1U & ((~ (((IData)(vlTOPp->vga_ball__DOT__hcount) 
				      >> 0xaU) & (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						   >> 9U) 
						  | ((IData)(vlTOPp->vga_ball__DOT__hcount) 
						     >> 8U)))) 
				 & (~ (((IData)(vlTOPp->vga_ball__DOT__vcount) 
					>> 9U) | (0xfU 
						  == 
						  (0xfU 
						   & ((IData)(vlTOPp->vga_ball__DOT__vcount) 
						      >> 5U)))))));
    // ALWAYS at vga_ball.sv:163
    if ((((IData)(vlTOPp->vga_ball__DOT__hcount) >= 
	  vlTOPp->vga_ball__DOT__h_start[0U]) & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
						 < 
						 vlTOPp->vga_ball__DOT__h_start
						 [1U]))) {
	vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
	    [0U];
	vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
	    [0U];
    } else {
	if ((((IData)(vlTOPp->vga_ball__DOT__hcount) 
	      >= vlTOPp->vga_ball__DOT__h_start[1U]) 
	     & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
		< vlTOPp->vga_ball__DOT__h_start[2U]))) {
	    vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
		[1U];
	    vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
		[1U];
	} else {
	    if ((((IData)(vlTOPp->vga_ball__DOT__hcount) 
		  >= vlTOPp->vga_ball__DOT__h_start
		  [2U]) & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
			   < vlTOPp->vga_ball__DOT__h_start
			   [3U]))) {
		vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
		    [2U];
		vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
		    [2U];
	    } else {
		if ((((IData)(vlTOPp->vga_ball__DOT__hcount) 
		      >= vlTOPp->vga_ball__DOT__h_start
		      [3U]) & ((IData)(vlTOPp->vga_ball__DOT__hcount) 
			       < vlTOPp->vga_ball__DOT__h_start
			       [4U]))) {
		    vlTOPp->vga_ball__DOT__ra_a = vlTOPp->vga_ball__DOT__sprite_ra_a
			[3U];
		    vlTOPp->vga_ball__DOT__ra_g = vlTOPp->vga_ball__DOT__sprite_ra_g
			[3U];
		} else {
		    if (((IData)(vlTOPp->vga_ball__DOT__hcount) 
			 >= vlTOPp->vga_ball__DOT__h_start
			 [4U])) {
			vlTOPp->vga_ball__DOT__ra_a 
			    = vlTOPp->vga_ball__DOT__sprite_ra_a
			    [4U];
			vlTOPp->vga_ball__DOT__ra_g 
			    = vlTOPp->vga_ball__DOT__sprite_ra_g
			    [4U];
		    } else {
			vlTOPp->vga_ball__DOT__ra_a = 0U;
			vlTOPp->vga_ball__DOT__ra_g = 0U;
		    }
		}
	    }
	}
    }
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp0__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp0__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp0__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [0U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp0__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp0__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp0__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp0__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp0__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp1__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp1__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp1__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [1U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp1__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp1__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp1__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp1__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp1__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp2__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp2__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp2__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [2U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp2__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp2__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp2__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp2__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp2__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp3__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp3__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp3__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [3U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp3__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp3__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp3__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp3__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp3__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:262
    vlTOPp->vga_ball__DOT__sp4__DOT__state_next = (
						   ((((((((0U 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state) 
							  | (1U 
							     == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
							 | (2U 
							    == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
							| (3U 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						       | (4U 
							  == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						      | (5U 
							 == vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						     | (6U 
							== vlTOPp->vga_ball__DOT__sp4__DOT__state)) 
						    | (7U 
						       == vlTOPp->vga_ball__DOT__sp4__DOT__state))
						    ? 
						   ((0U 
						     == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						     ? 
						    (((IData)(vlTOPp->vga_ball__DOT__hcount) 
						      == 
						      vlTOPp->vga_ball__DOT__h_start
						      [4U])
						      ? 1U
						      : 0U)
						     : 
						    ((1U 
						      == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						      ? 2U
						      : 
						     ((2U 
						       == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						       ? 3U
						       : 
						      ((3U 
							== vlTOPp->vga_ball__DOT__sp4__DOT__state)
						        ? 
						       ((((0x1ffU 
							   & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							  >= 
							  ((IData)(vlTOPp->vga_ball__DOT__dout_a) 
							   << 1U)) 
							 & ((0x1ffU 
							     & (IData)(vlTOPp->vga_ball__DOT__vcount)) 
							    < 
							    (0x1ffU 
							     & ((IData)(0x10U) 
								+ 
								((IData)(vlTOPp->vga_ball__DOT__dout_a) 
								 << 1U)))))
							 ? 4U
							 : 0U)
						        : 
						       ((4U 
							 == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							 ? 5U
							 : 
							((5U 
							  == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							  ? 6U
							  : 
							 ((6U 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							   ? 7U
							   : 8U)))))))
						    : 
						   ((8U 
						     == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						     ? 9U
						     : 
						    ((9U 
						      == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						      ? 0xaU
						      : 
						     ((0xaU 
						       == vlTOPp->vga_ball__DOT__sp4__DOT__state)
						       ? 0xbU
						       : 
						      ((0xbU 
							== vlTOPp->vga_ball__DOT__sp4__DOT__state)
						        ? 
						       ((0U 
							 == (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_reg_shift))
							 ? 0xcU
							 : 0xaU)
						        : 
						       ((0xcU 
							 == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							 ? 
							((0x7fU 
							  == (IData)(vlTOPp->vga_ball__DOT__hcount))
							  ? 0xdU
							  : 0xcU)
							 : 
							((0xdU 
							  == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							  ? 
							 ((0U 
							   == (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__down_counter))
							   ? 0xeU
							   : 0xdU)
							  : 
							 ((0xeU 
							   == vlTOPp->vga_ball__DOT__sp4__DOT__state)
							   ? 
							  ((0U 
							    == (IData)(vlTOPp->vga_ball__DOT__sp4__DOT__shift_pos))
							    ? 0U
							    : 0xeU)
							   : 0U))))))));
    // ALWAYS at vga_ball.sv:143
    vlTOPp->VGA_R = 0U;
    vlTOPp->VGA_G = 0U;
    vlTOPp->VGA_B = 0U;
    if (vlTOPp->VGA_BLANK_n) {
	if ((0U != (IData)(vlTOPp->vga_ball__DOT__final_out_pixel))) {
	    vlTOPp->VGA_R = (0xffU & (vlTOPp->vga_ball__DOT__rgb_val 
				      >> 0x10U));
	    vlTOPp->VGA_G = (0xffU & (vlTOPp->vga_ball__DOT__rgb_val 
				      >> 8U));
	    vlTOPp->VGA_B = (0xffU & vlTOPp->vga_ball__DOT__rgb_val);
	} else {
	    vlTOPp->VGA_R = vlTOPp->vga_ball__DOT__background_r;
	    vlTOPp->VGA_G = vlTOPp->vga_ball__DOT__background_g;
	    vlTOPp->VGA_B = vlTOPp->vga_ball__DOT__background_b;
	}
    }
}

void Vvga_ball::_eval(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_eval\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (((IData)(vlTOPp->clk) & (~ (IData)(vlTOPp->__Vclklast__TOP__clk)))) {
	vlTOPp->_sequent__TOP__3(vlSymsp);
	vlTOPp->__Vm_traceActivity = (2U | vlTOPp->__Vm_traceActivity);
    }
    if ((((IData)(vlTOPp->clk) & (~ (IData)(vlTOPp->__Vclklast__TOP__clk))) 
	 | ((IData)(vlTOPp->reset) & (~ (IData)(vlTOPp->__Vclklast__TOP__reset))))) {
	vlTOPp->_sequent__TOP__4(vlSymsp);
	vlTOPp->__Vm_traceActivity = (4U | vlTOPp->__Vm_traceActivity);
    }
    // Final
    vlTOPp->__Vclklast__TOP__clk = vlTOPp->clk;
    vlTOPp->__Vclklast__TOP__reset = vlTOPp->reset;
}

void Vvga_ball::_eval_initial(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_eval_initial\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_initial__TOP__1(vlSymsp);
}

void Vvga_ball::final() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::final\n"); );
    // Variables
    Vvga_ball__Syms* __restrict vlSymsp = this->__VlSymsp;
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
}

void Vvga_ball::_eval_settle(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_eval_settle\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_settle__TOP__2(vlSymsp);
    vlTOPp->__Vm_traceActivity = (1U | vlTOPp->__Vm_traceActivity);
}

VL_INLINE_OPT QData Vvga_ball::_change_request(Vvga_ball__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_change_request\n"); );
    Vvga_ball* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vvga_ball::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((clk & 0xfeU))) {
	Verilated::overWidthError("clk");}
    if (VL_UNLIKELY((reset & 0xfeU))) {
	Verilated::overWidthError("reset");}
    if (VL_UNLIKELY((write & 0xfeU))) {
	Verilated::overWidthError("write");}
    if (VL_UNLIKELY((chipselect & 0xfeU))) {
	Verilated::overWidthError("chipselect");}
    if (VL_UNLIKELY((address & 0xf0U))) {
	Verilated::overWidthError("address");}
}
#endif // VL_DEBUG

void Vvga_ball::_ctor_var_reset() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvga_ball::_ctor_var_reset\n"); );
    // Body
    clk = VL_RAND_RESET_I(1);
    reset = VL_RAND_RESET_I(1);
    writedata = VL_RAND_RESET_I(32);
    write = VL_RAND_RESET_I(1);
    chipselect = VL_RAND_RESET_I(1);
    address = VL_RAND_RESET_I(4);
    VGA_R = VL_RAND_RESET_I(8);
    VGA_G = VL_RAND_RESET_I(8);
    VGA_B = VL_RAND_RESET_I(8);
    VGA_CLK = VL_RAND_RESET_I(1);
    VGA_HS = VL_RAND_RESET_I(1);
    VGA_VS = VL_RAND_RESET_I(1);
    VGA_BLANK_n = VL_RAND_RESET_I(1);
    VGA_SYNC_n = VL_RAND_RESET_I(1);
    vga_ball__DOT__hcount = VL_RAND_RESET_I(11);
    vga_ball__DOT__vcount = VL_RAND_RESET_I(10);
    { int __Vi0=0; for (; __Vi0<6; ++__Vi0) {
	    vga_ball__DOT__out_pixel[__Vi0] = VL_RAND_RESET_I(4);
    }}
    vga_ball__DOT__final_out_pixel = VL_RAND_RESET_I(4);
    vga_ball__DOT__background_r = VL_RAND_RESET_I(8);
    vga_ball__DOT__background_g = VL_RAND_RESET_I(8);
    vga_ball__DOT__background_b = VL_RAND_RESET_I(8);
    vga_ball__DOT__rgb_val = VL_RAND_RESET_I(24);
    vga_ball__DOT__ra_n = VL_RAND_RESET_I(12);
    vga_ball__DOT__wa_n = VL_RAND_RESET_I(12);
    vga_ball__DOT__we_n = VL_RAND_RESET_I(1);
    vga_ball__DOT__din_n = VL_RAND_RESET_I(8);
    vga_ball__DOT__dout_n = VL_RAND_RESET_I(8);
    vga_ball__DOT__ra_pg = VL_RAND_RESET_I(11);
    vga_ball__DOT__wa_pg = VL_RAND_RESET_I(11);
    vga_ball__DOT__we_pg = VL_RAND_RESET_I(1);
    vga_ball__DOT__din_pg = VL_RAND_RESET_I(8);
    vga_ball__DOT__dout_pg = VL_RAND_RESET_I(8);
    vga_ball__DOT__ra_a = VL_RAND_RESET_I(5);
    vga_ball__DOT__wa_a = VL_RAND_RESET_I(5);
    vga_ball__DOT__we_a = VL_RAND_RESET_I(1);
    vga_ball__DOT__din_a = VL_RAND_RESET_I(8);
    vga_ball__DOT__dout_a = VL_RAND_RESET_I(8);
    vga_ball__DOT__ra_g = VL_RAND_RESET_I(11);
    vga_ball__DOT__wa_g = VL_RAND_RESET_I(11);
    vga_ball__DOT__we_g = VL_RAND_RESET_I(1);
    vga_ball__DOT__din_g = VL_RAND_RESET_I(8);
    vga_ball__DOT__dout_g = VL_RAND_RESET_I(8);
    { int __Vi0=0; for (; __Vi0<5; ++__Vi0) {
	    vga_ball__DOT__sprite_base_addr[__Vi0] = VL_RAND_RESET_I(5);
    }}
    { int __Vi0=0; for (; __Vi0<5; ++__Vi0) {
	    vga_ball__DOT__h_start[__Vi0] = VL_RAND_RESET_I(11);
    }}
    { int __Vi0=0; for (; __Vi0<5; ++__Vi0) {
	    vga_ball__DOT__sprite_ra_a[__Vi0] = VL_RAND_RESET_I(5);
    }}
    { int __Vi0=0; for (; __Vi0<5; ++__Vi0) {
	    vga_ball__DOT__sprite_ra_g[__Vi0] = VL_RAND_RESET_I(11);
    }}
    vga_ball__DOT____Vcellout__sp0__ra_g = VL_RAND_RESET_I(11);
    vga_ball__DOT____Vcellout__sp0__ra_a = VL_RAND_RESET_I(5);
    vga_ball__DOT____Vcellout__sp1__ra_g = VL_RAND_RESET_I(11);
    vga_ball__DOT____Vcellout__sp1__ra_a = VL_RAND_RESET_I(5);
    vga_ball__DOT____Vcellout__sp2__ra_g = VL_RAND_RESET_I(11);
    vga_ball__DOT____Vcellout__sp2__ra_a = VL_RAND_RESET_I(5);
    vga_ball__DOT____Vcellout__sp3__ra_g = VL_RAND_RESET_I(11);
    vga_ball__DOT____Vcellout__sp3__ra_a = VL_RAND_RESET_I(5);
    vga_ball__DOT____Vcellout__sp4__ra_g = VL_RAND_RESET_I(11);
    vga_ball__DOT____Vcellout__sp4__ra_a = VL_RAND_RESET_I(5);
    vga_ball__DOT__counters__DOT__endOfLine = VL_RAND_RESET_I(1);
    vga_ball__DOT__counters__DOT__endOfField = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<4096; ++__Vi0) {
	    vga_ball__DOT__pn1__DOT__mem[__Vi0] = VL_RAND_RESET_I(8);
    }}
    { int __Vi0=0; for (; __Vi0<2048; ++__Vi0) {
	    vga_ball__DOT__pg1__DOT__mem[__Vi0] = VL_RAND_RESET_I(8);
    }}
    { int __Vi0=0; for (; __Vi0<32; ++__Vi0) {
	    vga_ball__DOT__sat1__DOT__mem[__Vi0] = VL_RAND_RESET_I(8);
    }}
    { int __Vi0=0; for (; __Vi0<2048; ++__Vi0) {
	    vga_ball__DOT__sgt1__DOT__mem[__Vi0] = VL_RAND_RESET_I(8);
    }}
    VL_RAND_RESET_W(2048,vga_ball__DOT__pp0__DOT__shift_reg);
    vga_ball__DOT__pp0__DOT__shift_pos = VL_RAND_RESET_I(12);
    vga_ball__DOT__pp0__DOT__pattern_row_offset = VL_RAND_RESET_I(11);
    VL_RAND_RESET_W(2048,vga_ball__DOT__pp0__DOT__display_pixel);
    vga_ball__DOT__pp0__DOT__shift_reg_shift = VL_RAND_RESET_I(12);
    vga_ball__DOT__pp0__DOT__tile_total_counter = VL_RAND_RESET_I(8);
    vga_ball__DOT__pp0__DOT__tile_pixel_counter = VL_RAND_RESET_I(8);
    vga_ball__DOT__pp0__DOT__state = 0;
    vga_ball__DOT__pp0__DOT__state_next = 0;
    vga_ball__DOT__sp0__DOT__down_counter = VL_RAND_RESET_I(9);
    vga_ball__DOT__sp0__DOT__shift_reg = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp0__DOT__shift_pos = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp0__DOT__sprite_offset = VL_RAND_RESET_I(11);
    vga_ball__DOT__sp0__DOT__display_pixel = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp0__DOT__shift_reg_shift = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp0__DOT__state = 0;
    vga_ball__DOT__sp0__DOT__state_next = 0;
    vga_ball__DOT__sp1__DOT__down_counter = VL_RAND_RESET_I(9);
    vga_ball__DOT__sp1__DOT__shift_reg = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp1__DOT__shift_pos = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp1__DOT__sprite_offset = VL_RAND_RESET_I(11);
    vga_ball__DOT__sp1__DOT__display_pixel = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp1__DOT__shift_reg_shift = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp1__DOT__state = 0;
    vga_ball__DOT__sp1__DOT__state_next = 0;
    vga_ball__DOT__sp2__DOT__down_counter = VL_RAND_RESET_I(9);
    vga_ball__DOT__sp2__DOT__shift_reg = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp2__DOT__shift_pos = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp2__DOT__sprite_offset = VL_RAND_RESET_I(11);
    vga_ball__DOT__sp2__DOT__display_pixel = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp2__DOT__shift_reg_shift = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp2__DOT__state = 0;
    vga_ball__DOT__sp2__DOT__state_next = 0;
    vga_ball__DOT__sp3__DOT__down_counter = VL_RAND_RESET_I(9);
    vga_ball__DOT__sp3__DOT__shift_reg = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp3__DOT__shift_pos = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp3__DOT__sprite_offset = VL_RAND_RESET_I(11);
    vga_ball__DOT__sp3__DOT__display_pixel = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp3__DOT__shift_reg_shift = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp3__DOT__state = 0;
    vga_ball__DOT__sp3__DOT__state_next = 0;
    vga_ball__DOT__sp4__DOT__down_counter = VL_RAND_RESET_I(9);
    vga_ball__DOT__sp4__DOT__shift_reg = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp4__DOT__shift_pos = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp4__DOT__sprite_offset = VL_RAND_RESET_I(11);
    vga_ball__DOT__sp4__DOT__display_pixel = VL_RAND_RESET_Q(64);
    vga_ball__DOT__sp4__DOT__shift_reg_shift = VL_RAND_RESET_I(8);
    vga_ball__DOT__sp4__DOT__state = 0;
    vga_ball__DOT__sp4__DOT__state_next = 0;
    __Vtableidx1 = VL_RAND_RESET_I(4);
    __Vtable1_vga_ball__DOT__rgb_val[0] = 0xffffffU;
    __Vtable1_vga_ball__DOT__rgb_val[1] = 0xfef104U;
    __Vtable1_vga_ball__DOT__rgb_val[2] = 0xfe0e03U;
    __Vtable1_vga_ball__DOT__rgb_val[3] = 0xfeb846U;
    __Vtable1_vga_ball__DOT__rgb_val[4] = 0xecfeU;
    __Vtable1_vga_ball__DOT__rgb_val[5] = 0xfdbff9U;
    __Vtable1_vga_ball__DOT__rgb_val[6] = 0xe5dfeeU;
    __Vtable1_vga_ball__DOT__rgb_val[7] = 0x1e26b8U;
    __Vtable1_vga_ball__DOT__rgb_val[8] = 0xffc0b7U;
    __Vtable1_vga_ball__DOT__rgb_val[9] = 0xffffffU;
    __Vtable1_vga_ball__DOT__rgb_val[10] = 0xffffffU;
    __Vtable1_vga_ball__DOT__rgb_val[11] = 0xffffffU;
    __Vtable1_vga_ball__DOT__rgb_val[12] = 0xffffffU;
    __Vtable1_vga_ball__DOT__rgb_val[13] = 0xffffffU;
    __Vtable1_vga_ball__DOT__rgb_val[14] = 0xffffffU;
    __Vtable1_vga_ball__DOT__rgb_val[15] = 0xffffffU;
    __Vclklast__TOP__clk = VL_RAND_RESET_I(1);
    __Vclklast__TOP__reset = VL_RAND_RESET_I(1);
    __Vm_traceActivity = VL_RAND_RESET_I(32);
}
