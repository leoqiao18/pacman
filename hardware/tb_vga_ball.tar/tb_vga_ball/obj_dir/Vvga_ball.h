// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary design header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef _Vvga_ball_H_
#define _Vvga_ball_H_

#include "verilated.h"

class Vvga_ball__Syms;
class VerilatedVcd;

//----------

VL_MODULE(Vvga_ball) {
  public:
    
    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    VL_IN8(clk,0,0);
    VL_IN8(reset,0,0);
    VL_IN8(write,0,0);
    VL_IN8(chipselect,0,0);
    VL_IN8(address,3,0);
    VL_OUT8(VGA_R,7,0);
    VL_OUT8(VGA_G,7,0);
    VL_OUT8(VGA_B,7,0);
    VL_OUT8(VGA_CLK,0,0);
    VL_OUT8(VGA_HS,0,0);
    VL_OUT8(VGA_VS,0,0);
    VL_OUT8(VGA_BLANK_n,0,0);
    VL_OUT8(VGA_SYNC_n,0,0);
    VL_IN(writedata,31,0);
    
    // LOCAL SIGNALS
    // Internals; generally not touched by application code
    // Anonymous structures to workaround compiler member-count bugs
    struct {
	VL_SIG8(vga_ball__DOT__final_out_pixel,3,0);
	VL_SIG8(vga_ball__DOT__background_r,7,0);
	VL_SIG8(vga_ball__DOT__background_g,7,0);
	VL_SIG8(vga_ball__DOT__background_b,7,0);
	VL_SIG8(vga_ball__DOT__we_n,0,0);
	VL_SIG8(vga_ball__DOT__din_n,7,0);
	VL_SIG8(vga_ball__DOT__dout_n,7,0);
	VL_SIG8(vga_ball__DOT__we_pg,0,0);
	VL_SIG8(vga_ball__DOT__din_pg,7,0);
	VL_SIG8(vga_ball__DOT__dout_pg,7,0);
	VL_SIG8(vga_ball__DOT__ra_a,4,0);
	VL_SIG8(vga_ball__DOT__wa_a,4,0);
	VL_SIG8(vga_ball__DOT__we_a,0,0);
	VL_SIG8(vga_ball__DOT__din_a,7,0);
	VL_SIG8(vga_ball__DOT__dout_a,7,0);
	VL_SIG8(vga_ball__DOT__we_g,0,0);
	VL_SIG8(vga_ball__DOT__din_g,7,0);
	VL_SIG8(vga_ball__DOT__dout_g,7,0);
	VL_SIG8(vga_ball__DOT__counters__DOT__endOfLine,0,0);
	VL_SIG8(vga_ball__DOT__counters__DOT__endOfField,0,0);
	VL_SIG8(vga_ball__DOT__pp0__DOT__tile_total_counter,7,0);
	VL_SIG8(vga_ball__DOT__pp0__DOT__tile_pixel_counter,7,0);
	VL_SIG8(vga_ball__DOT__sp0__DOT__shift_pos,7,0);
	VL_SIG8(vga_ball__DOT__sp0__DOT__shift_reg_shift,7,0);
	VL_SIG8(vga_ball__DOT__sp1__DOT__shift_pos,7,0);
	VL_SIG8(vga_ball__DOT__sp1__DOT__shift_reg_shift,7,0);
	VL_SIG8(vga_ball__DOT__sp2__DOT__shift_pos,7,0);
	VL_SIG8(vga_ball__DOT__sp2__DOT__shift_reg_shift,7,0);
	VL_SIG8(vga_ball__DOT__sp3__DOT__shift_pos,7,0);
	VL_SIG8(vga_ball__DOT__sp3__DOT__shift_reg_shift,7,0);
	VL_SIG8(vga_ball__DOT__sp4__DOT__shift_pos,7,0);
	VL_SIG8(vga_ball__DOT__sp4__DOT__shift_reg_shift,7,0);
	VL_SIG16(vga_ball__DOT__hcount,10,0);
	VL_SIG16(vga_ball__DOT__vcount,9,0);
	VL_SIG16(vga_ball__DOT__ra_n,11,0);
	VL_SIG16(vga_ball__DOT__wa_n,11,0);
	VL_SIG16(vga_ball__DOT__ra_pg,10,0);
	VL_SIG16(vga_ball__DOT__wa_pg,10,0);
	VL_SIG16(vga_ball__DOT__ra_g,10,0);
	VL_SIG16(vga_ball__DOT__wa_g,10,0);
	VL_SIG16(vga_ball__DOT__pp0__DOT__shift_pos,11,0);
	VL_SIG16(vga_ball__DOT__pp0__DOT__pattern_row_offset,10,0);
	VL_SIG16(vga_ball__DOT__pp0__DOT__shift_reg_shift,11,0);
	VL_SIG16(vga_ball__DOT__sp0__DOT__down_counter,8,0);
	VL_SIG16(vga_ball__DOT__sp0__DOT__sprite_offset,10,0);
	VL_SIG16(vga_ball__DOT__sp1__DOT__down_counter,8,0);
	VL_SIG16(vga_ball__DOT__sp1__DOT__sprite_offset,10,0);
	VL_SIG16(vga_ball__DOT__sp2__DOT__down_counter,8,0);
	VL_SIG16(vga_ball__DOT__sp2__DOT__sprite_offset,10,0);
	VL_SIG16(vga_ball__DOT__sp3__DOT__down_counter,8,0);
	VL_SIG16(vga_ball__DOT__sp3__DOT__sprite_offset,10,0);
	VL_SIG16(vga_ball__DOT__sp4__DOT__down_counter,8,0);
	VL_SIG16(vga_ball__DOT__sp4__DOT__sprite_offset,10,0);
	VL_SIG(vga_ball__DOT__rgb_val,23,0);
	VL_SIGW(vga_ball__DOT__pp0__DOT__shift_reg,2047,0,64);
	VL_SIGW(vga_ball__DOT__pp0__DOT__display_pixel,2047,0,64);
	VL_SIG(vga_ball__DOT__pp0__DOT__state,31,0);
	VL_SIG(vga_ball__DOT__pp0__DOT__state_next,31,0);
	VL_SIG(vga_ball__DOT__sp0__DOT__state,31,0);
	VL_SIG(vga_ball__DOT__sp0__DOT__state_next,31,0);
	VL_SIG(vga_ball__DOT__sp1__DOT__state,31,0);
	VL_SIG(vga_ball__DOT__sp1__DOT__state_next,31,0);
	VL_SIG(vga_ball__DOT__sp2__DOT__state,31,0);
	VL_SIG(vga_ball__DOT__sp2__DOT__state_next,31,0);
    };
    struct {
	VL_SIG(vga_ball__DOT__sp3__DOT__state,31,0);
	VL_SIG(vga_ball__DOT__sp3__DOT__state_next,31,0);
	VL_SIG(vga_ball__DOT__sp4__DOT__state,31,0);
	VL_SIG(vga_ball__DOT__sp4__DOT__state_next,31,0);
	VL_SIG64(vga_ball__DOT__sp0__DOT__shift_reg,63,0);
	VL_SIG64(vga_ball__DOT__sp0__DOT__display_pixel,63,0);
	VL_SIG64(vga_ball__DOT__sp1__DOT__shift_reg,63,0);
	VL_SIG64(vga_ball__DOT__sp1__DOT__display_pixel,63,0);
	VL_SIG64(vga_ball__DOT__sp2__DOT__shift_reg,63,0);
	VL_SIG64(vga_ball__DOT__sp2__DOT__display_pixel,63,0);
	VL_SIG64(vga_ball__DOT__sp3__DOT__shift_reg,63,0);
	VL_SIG64(vga_ball__DOT__sp3__DOT__display_pixel,63,0);
	VL_SIG64(vga_ball__DOT__sp4__DOT__shift_reg,63,0);
	VL_SIG64(vga_ball__DOT__sp4__DOT__display_pixel,63,0);
	VL_SIG8(vga_ball__DOT__out_pixel[6],3,0);
	VL_SIG8(vga_ball__DOT__sprite_base_addr[5],4,0);
	VL_SIG16(vga_ball__DOT__h_start[5],10,0);
	VL_SIG8(vga_ball__DOT__sprite_ra_a[5],4,0);
	VL_SIG16(vga_ball__DOT__sprite_ra_g[5],10,0);
	VL_SIG8(vga_ball__DOT__pn1__DOT__mem[4096],7,0);
	VL_SIG8(vga_ball__DOT__pg1__DOT__mem[2048],7,0);
	VL_SIG8(vga_ball__DOT__sat1__DOT__mem[32],7,0);
	VL_SIG8(vga_ball__DOT__sgt1__DOT__mem[2048],7,0);
    };
    
    // LOCAL VARIABLES
    // Internals; generally not touched by application code
    VL_SIG8(vga_ball__DOT____Vcellout__sp0__ra_a,4,0);
    VL_SIG8(vga_ball__DOT____Vcellout__sp1__ra_a,4,0);
    VL_SIG8(vga_ball__DOT____Vcellout__sp2__ra_a,4,0);
    VL_SIG8(vga_ball__DOT____Vcellout__sp3__ra_a,4,0);
    VL_SIG8(vga_ball__DOT____Vcellout__sp4__ra_a,4,0);
    VL_SIG8(__Vtableidx1,3,0);
    VL_SIG8(__Vclklast__TOP__clk,0,0);
    VL_SIG8(__Vclklast__TOP__reset,0,0);
    VL_SIG16(vga_ball__DOT____Vcellout__sp0__ra_g,10,0);
    VL_SIG16(vga_ball__DOT____Vcellout__sp1__ra_g,10,0);
    VL_SIG16(vga_ball__DOT____Vcellout__sp2__ra_g,10,0);
    VL_SIG16(vga_ball__DOT____Vcellout__sp3__ra_g,10,0);
    VL_SIG16(vga_ball__DOT____Vcellout__sp4__ra_g,10,0);
    VL_SIG(__Vm_traceActivity,31,0);
    static VL_ST_SIG(__Vtable1_vga_ball__DOT__rgb_val[16],23,0);
    
    // INTERNAL VARIABLES
    // Internals; generally not touched by application code
    Vvga_ball__Syms* __VlSymsp;  // Symbol table
    
    // PARAMETERS
    // Parameters marked /*verilator public*/ for use by application code
    
    // CONSTRUCTORS
  private:
    VL_UNCOPYABLE(Vvga_ball);  ///< Copying not allowed
  public:
    /// Construct the model; called by application code
    /// The special name  may be used to make a wrapper with a
    /// single model invisible with respect to DPI scope names.
    Vvga_ball(const char* name="TOP");
    /// Destroy the model; called (often implicitly) by application code
    ~Vvga_ball();
    /// Trace signals in the model; called by application code
    void trace(VerilatedVcdC* tfp, int levels, int options=0);
    
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval();
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    
    // INTERNAL METHODS
  private:
    static void _eval_initial_loop(Vvga_ball__Syms* __restrict vlSymsp);
  public:
    void __Vconfigure(Vvga_ball__Syms* symsp, bool first);
  private:
    static QData _change_request(Vvga_ball__Syms* __restrict vlSymsp);
    void _ctor_var_reset();
  public:
    static void _eval(Vvga_ball__Syms* __restrict vlSymsp);
  private:
#ifdef VL_DEBUG
    void _eval_debug_assertions();
#endif // VL_DEBUG
  public:
    static void _eval_initial(Vvga_ball__Syms* __restrict vlSymsp);
    static void _eval_settle(Vvga_ball__Syms* __restrict vlSymsp);
    static void _initial__TOP__1(Vvga_ball__Syms* __restrict vlSymsp);
    static void _sequent__TOP__3(Vvga_ball__Syms* __restrict vlSymsp);
    static void _sequent__TOP__4(Vvga_ball__Syms* __restrict vlSymsp);
    static void _settle__TOP__2(Vvga_ball__Syms* __restrict vlSymsp);
    static void traceChgThis(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__2(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__3(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__4(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__5(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__6(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__7(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceFullThis(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceFullThis__1(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceInitThis(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceInitThis__1(Vvga_ball__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceInit(VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceFull(VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceChg(VerilatedVcd* vcdp, void* userthis, uint32_t code);
} VL_ATTR_ALIGNED(128);

#endif // guard
